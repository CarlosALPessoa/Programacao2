package br.ufal.ic.p2.wepayu.models;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class Horista extends Empregado {
	//Horistas lancamento cartão
	private Map<String, String> horasTrabalhadas = new LinkedHashMap<>();

	// CONSTRUTOR
	public Horista(String nome, String endereco, String tipo, String salario){
		super(nome, endereco, tipo, salario);
		this.diaPaga = "";
	}
	
	/*
	 * 
	 * GETTERS E SETTERS
	 * 
	 * */	
	@Override
	public void setDiaPaga(String diaPaga) {
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		 LocalDate temp = LocalDate.parse(diaPaga, formatter).plusDays(7);	
		 DayOfWeek diaSemana = temp.getDayOfWeek();
		 if(diaSemana == DayOfWeek.SATURDAY) {
			 temp = temp.minusDays(1);
		 }
		 if(diaSemana == DayOfWeek.SUNDAY) {
			 temp = temp.minusDays(2);
		 }
		this.diaPaga = temp.format(formatter);
	}
	
	public void setHorasTrabalhadas(String data, String horas) {
		this.horasTrabalhadas.put(data, horas);
		if(this.diaPaga.isEmpty() ) {
			setDiaPaga(data);
		}
	}
	
	public Map<String, String> getHorasTrabalhadas() {
		return horasTrabalhadas;
	}
	
	/*
	 * 
	 * Funções
	 * 
	 * */
}