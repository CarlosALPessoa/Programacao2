package Exceptions;

public class ErrorConvert extends Exception{
	private static final long serialVersionUID = 1L;

	public ErrorConvert() {
		super("Erro ao converter String/Double/Float");
	}
}
