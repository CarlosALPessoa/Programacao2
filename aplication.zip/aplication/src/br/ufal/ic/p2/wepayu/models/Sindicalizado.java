package br.ufal.ic.p2.wepayu.models;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class Sindicalizado extends Empregado {
	private String comissao;
	private String metododePagamento;
	private String banco = "";
	private String agencia = "";
	private String cc = "";
	private String idSind;
	private String taxaSindical;
	private String datePag;
	
	private LocalDate diaDePagamento;
	private String realSalario;

	private Map<String, Float> valorSindicalTaxa;
	private Map<String, Float> horasTrabalhadas;
	private Map<String, Float> vComissaoVenda;

	//Construtor
	public Sindicalizado(String nome, String endereco, String tipo, String salario, String sindicalizado,
			String metododePagamento, String banco, String agencia, String cc, String id, String taxa) throws Exception {
		super(nome, endereco, tipo, salario);

		this.metododePagamento = metododePagamento;
		this.banco = banco;
		this.agencia = agencia;
		this.cc = cc;
		this.setSindicalizado(sindicalizado);
		this.idSind = id;
		this.taxaSindical = taxa;
		
		//Inicializando outras questoes
		setrealSalario(salario);
		setDiaDePagamento("1/1/2005");
		
		
		//Inicializando listas
		this.valorSindicalTaxa = new LinkedHashMap<>();
		this.horasTrabalhadas = new LinkedHashMap<>();
		this.vComissaoVenda = new LinkedHashMap<>();
	}
	
	//Para o comissionado
	public Float pFolhaQuinzenal(String data) throws Exception {
		LocalDate dataFim = converterFim(data);
		LocalDate diaPag = getDiaDePagamento();
		Integer menosdia = 0;
		if (diaPag.getDayOfWeek() == DayOfWeek.SATURDAY) {
			diaPag = diaPag.minusDays(1);
			menosdia = 1;
		} else if (diaPag.getDayOfWeek() == DayOfWeek.SUNDAY) {
			diaPag = diaPag.minusDays(2);
			menosdia = 2;
		}

		Float salarioNormal = Float.parseFloat(getRealSalario().replace(",", "."));
		
		Float salarioComissao = 0.00f;

		while (diaPag.isBefore(dataFim) || diaPag.equals(dataFim)) {
			if (diaPag.equals(dataFim)) {
				dataFim = dataFim.plusDays(1);
				diaPag = getDiaDePagamento().minusDays(14);
				if (!vComissaoVenda.isEmpty()) {
					
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
					String dataInicial = formatter.format(diaPag);
					String datafims = formatter.format(dataFim);
					Float totalValorVendas = Float.parseFloat(obterValor(dataInicial, datafims).replace(",", "."));
					
					Float ganhoRate = totalValorVendas * Float.parseFloat(getComissao().replace(",", "."));
					salarioComissao = salarioNormal + ganhoRate;
					
					setDiaDePagamento(data);
					Integer salarioComissaoi = (int) (salarioComissao * 100);
					salarioComissao = salarioComissaoi / 100.0f;
					
					
					return salarioComissao;
				}
				setDiaDePagamento(data);
				Integer salarioComissaoi = (int) (salarioNormal * 100);
				salarioNormal = salarioComissaoi / 100.0f;
				return salarioNormal;
			}
			diaPag = diaPag.plusDays(15 - menosdia);
		}
		return 0.00f;
	}
	
	//Retornar TaxaSindical
	public String obterTaxaSindical(String inicio, String fim) throws Exception {
		Float sindicalTaxas = 0.00f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior aa data final.");
		}

		// Imprime a data convertida

		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = valorSindicalTaxa.get(dates);

			if (objeto != null) {
				sindicalTaxas += objeto;
			}
		}
		if (sindicalTaxas != 0) {
			return String.format("%.2f", sindicalTaxas);
		}
		return "0,00";
	}

	// Retorna para o totalFolha
	public Float PagamentoFolha(String data) throws Exception {

		// Pega data final para conferir se é um dia de pagamento para o horista
		LocalDate dataFim = converterFim(data);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		// Se o funcionario lançou cartão entra, caso nao cancela o retorno do salário
		// semanal
		LocalDate diadePagamento;
		if (getdatePag() != null) {
			diadePagamento = LocalDate.parse(getdatePag(), formatter);
		} else {
			return 0.00f;
		}

		// Usadas para somar as horas * salário
		Float salarioNormal = 0.00f;
		Float salarioExtra = 0.00f;
		Float deducaoTipo = 0.00f;
		
		// Percorre procurando dias de pagamento
		while (diadePagamento.isBefore(dataFim) || diadePagamento.equals(dataFim)) {
			if (diadePagamento.equals(dataFim)) {
				// passa o primeiro dia do pagamento.
				diadePagamento = diadePagamento.minusDays(6);
				// Percorre os dias para pegar as horas diarias

				// Converte a data inicial da semana de pagamento
				dataFim = dataFim.plusDays(1);
				String diaObterInicial = diadePagamento.format(formatter);
				String diaObterFinal = dataFim.format(formatter);

				//Pega o salario por semana do horista
					String horasNormais = obterHorasNormaisTrabalhadas(diaObterInicial, diaObterFinal);
					String horasExtras = extrasHoras(diaObterInicial, diaObterFinal);
					
					salarioNormal = Float.parseFloat(getSalario().replace(",", ".")) * Float.parseFloat(horasNormais);
					salarioExtra = (float) (Float.parseFloat(getSalario().replace(",", ".")) * 1.5f)
							* Float.parseFloat(horasExtras.replace(",", "."));
					
					//Confere se tiveram taxas lançadas por ser sindicalizado
					/*if(!valorSindicalTaxa.isEmpty() || valorSindicalTaxa != null) {
						deducaoTipo += Float.parseFloat(obterTaxaSindical(diaObterInicial, diaObterFinal).replace(",", "."));
					}
					
					deducaoTipo += Float.parseFloat(getTaxaSindical().replace(",", ".")) * 7.0f;*/
					
					if(deducaoTipo >= 0.0) {
						setdatePag(data);
						return (float) salarioNormal + salarioExtra - deducaoTipo;
					}
				setdatePag(data);
				// System.out.println(salarioNormal + salarioExtra + "Aqui soma");
				return 0.0f;
			}
			diadePagamento = diadePagamento.plusDays(7); // Adiciona mais 7 dias à data atual
		}
		return 0.0f;
	}
	
	//Funcao de sindicalizacao
	public void registrarTaxaServico(String data, Float valor) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);

			valorSindicalTaxa.put(data, valor);
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}

	//Funcoes de validacao e conversao
	public Boolean validarData(String dtf) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		sdf.setLenient(false); // Impede interpretações flexíveis, ou seja, datas inválidas serão rejeitadas

		try {
			sdf.parse(dtf);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	private LocalDate converterFim(String fim) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate dtf = LocalDate.parse(fim, formatter);
			if (validarData(fim)) {
				return dtf;
			} else {
				throw new Exception("Data final invalida.");
			}
		} catch (Exception e) {
			throw new Exception("Data final invalida.");
		}
	}

	private LocalDate converterInicio(String inicio) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new Exception("Data inicial invalida.");
		}
	}
	//Fim funcoes validacao e conversao

	public String obterTaxaComissao(String inicio, String fim) throws Exception {
		Float comissao = 0.00f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior aa data final.");
		}

		// Imprime a data convertida

		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = valorSindicalTaxa.get(dates);

			if (objeto != null) {
				comissao += objeto;
			}
		}
		if (comissao != 0) {
			return String.format("%.2f", comissao);
		}
		return "0,00";
	}

	// Funcoes de sindicalizado horista
	public void registrarHorasTrabalhadas(String data, Float horas) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);
			if(datePag == null) {
				LocalDate diadePagamento = LocalDate.parse(data, formatter);
				diadePagamento = diadePagamento.plusDays(6);
				data = diadePagamento.format(formatter);	
				setdatePag(data);
			}
			horasTrabalhadas.put(data, horas);
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}

	public String extrasHoras(String inicio, String fim) throws Exception {
		Float HorasExtras = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);
		// Imprime a data convertida
		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = horasTrabalhadas.get(dates);

			if (objeto != null) {
				if (objeto > 8) {
					HorasExtras += objeto % 8;
				}
			}
		}
		if (HorasExtras % 1 != 0) {
			// DecimalFormat formato = new DecimalFormat("#,##0.00");
			// String horas = formato.format(HorasExtras);
			// System.out.println(horas);
			return String.format("%.1f", HorasExtras);
		} else {
			return String.format("%d", Float.valueOf(HorasExtras).intValue());
		}
	}

	public String obterHorasNormaisTrabalhadas(String inicio, String fim) throws Exception {
		int normalHoras = 0;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior aa data final.");
		}

		// Imprime a data convertida
		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = horasTrabalhadas.get(dates);

			if (objeto != null) {
				if (objeto > 8) {
					normalHoras += 8;
				} else if (objeto <= 8 && objeto > 0) {
					normalHoras += objeto;
				}
			}

		}
		if (normalHoras != 0) {
			return String.format("%d", normalHoras);
		}
		return "0";

	}

	// Funcoes do Comissionado
	public void registrarValor(String data, Float valor) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);
			vComissaoVenda.put(data, valor);
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}

	public String obterValor(String inicio, String fim) throws Exception {
		// Retorna valor da comissao
		Float comissao = 0.00f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior aa data final.");
		}

		// Imprime a data convertida

		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = vComissaoVenda.get(dates);

			if (objeto != null) {
				comissao += objeto;
			}
		}
		if (comissao != 0) {
			return String.format("%.2f", comissao);
		}
		return "0,00";
	}

	// variaveis getter e setters
	

	public LocalDate getDiaDePagamento() {
		return diaDePagamento;
	}

	public void setDiaDePagamento(String string) throws Exception {
		LocalDate x = converterInicio(string);
		this.diaDePagamento = x.plusDays(14);
		return;
	}

	public String getRealSalario() {
		return realSalario;
	}

	@SuppressWarnings("deprecation")
	public void setrealSalario(String realSalario) {
		BigDecimal salary = new BigDecimal(realSalario.replace(",", "."));
        salary = salary.multiply(BigDecimal.valueOf(12.0)).divide(BigDecimal.valueOf(52.0), 2, BigDecimal.ROUND_HALF_UP);
        salary = salary.multiply(BigDecimal.valueOf(2));
        DecimalFormat decimalFormatter = new DecimalFormat("#,##0.00");
        this.realSalario = decimalFormatter.format(salary);
	}

	public Map<String, Float> getValorSindicalTaxa() {
		return valorSindicalTaxa;
	}

	public void setValorSindicalTaxa(Map<String, Float> valorSindicalTaxa) {
		this.valorSindicalTaxa = valorSindicalTaxa;
	}

	public String getdatePag() {
		return datePag;
	}

	public void setdatePag(String datePag) {
		this.datePag = datePag;
	}

	public String getComissao() {
		return comissao;
	}

	public String setComissao(String comissao) {
		float num = Float.parseFloat(comissao.replace(",", "."));
		return this.comissao = String.format("%.2f", num);
	}

	public String getMetododePagamento() {
		return metododePagamento;
	}

	public void setMetododePagamento(String metododePagamento) {
		this.metododePagamento = metododePagamento;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getIdSind() {
		return idSind;
	}

	public void setIdSind(String idSind) {
		this.idSind = idSind;
	}

	public String getTaxaSindical() {
		float num = Float.parseFloat(this.taxaSindical.replace(",", "."));
		return String.format("%.2f", num);
	}

	public String setTaxaSindical(String taxaSindical) {
		float num = Float.parseFloat(taxaSindical.replace(",", "."));
		return String.format("%.2f", num);
	}
}