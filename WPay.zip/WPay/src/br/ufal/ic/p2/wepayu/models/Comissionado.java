package br.ufal.ic.p2.wepayu.models;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class Comissionado extends Empregado {
	private Map<String, Float> vComissaoVenda;
	private LocalDate diaDePagamento;
	private String realSalario;
	private String comissao;

//Construtor
	public Comissionado(String nome, String endereco, String tipo, String salario, String comissao) throws Exception {
		super(nome, endereco, tipo, salario);
		this.comissao = comissao;
		setTipo("comissionado");
		this.comissao = comissao;
		this.vComissaoVenda = new LinkedHashMap<>();
		setrealSalario(salario);
		setDiaPaga(LocalDate.parse("1/1/2005").plusDays(14));
	}
	
	@Override
	public void setDiaPaga(LocalDate diaPaga) {
		this.diaPaga = diaPaga;
	}

	public String getComissao() {
		return comissao;
	}

	public void setComissao(String comissao) {
		this.comissao = comissao;
	}
	public Float pFolhaQuinzenal(String data) throws Exception {
		LocalDate dataFim = converterFim(data);
		LocalDate diaPag = getDiaDePagamento();
		Integer menosdia = 0;
		if (diaPag.getDayOfWeek() == DayOfWeek.SATURDAY) {
			diaPag = diaPag.minusDays(1);
			menosdia = 1;
		} else if (diaPag.getDayOfWeek() == DayOfWeek.SUNDAY) {
			diaPag = diaPag.minusDays(2);
			menosdia = 2;
		}

		Float salarioNormal = (float) Float.parseFloat(getRealSalario().replace(",", "."));
		Float salarioComissao = 0.00f;

		while (diaPag.isBefore(dataFim) || diaPag.equals(dataFim)) {
			if (diaPag.equals(dataFim)) {
				dataFim = dataFim.plusDays(1);
				diaPag = getDiaDePagamento().minusDays(14);
				if (!vComissaoVenda.isEmpty()) {
					
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
					String dataInicial = formatter.format(diaPag);
					String datafims = formatter.format(dataFim);
					Float totalValorVendas = Float.parseFloat(obterValor(dataInicial, datafims).replace(",", "."));
					
					float ganhoRate = totalValorVendas * Float.parseFloat(getComissao().replace(",", "."));
					salarioComissao = salarioNormal + ganhoRate;
					
					Integer salarioComissaoi = (int) (salarioComissao * 100);
					salarioComissao = salarioComissaoi / 100.0f;
					
					setDiaDePagamento(data);
					return salarioComissao;
				}
				Integer salarioComissaoi = (int) (salarioNormal * 100);
				salarioNormal = salarioComissaoi / 100.0f;
				setDiaDePagamento(data);
				return salarioNormal;
			}
			diaPag = diaPag.plusDays(15 - menosdia);
		}
		return 0.00f;
	}

	public void registrarValor(String data, Float valor) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);
			vComissaoVenda.put(data, valor);
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}
	//// fim registro

	private LocalDate converterInicio(String inicio) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new Exception("Data inicial invalida.");
		}
	}

	public Boolean validarData(String dtf) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		sdf.setLenient(false); // Impede interpretações flexíveis, ou seja, datas inválidas serão rejeitadas

		try {
			sdf.parse(dtf);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	private LocalDate converterFim(String fim) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate dtf = LocalDate.parse(fim, formatter);
			if (validarData(fim)) {
				return dtf;
			} else {
				throw new Exception("Data final invalida.");
			}
		} catch (Exception e) {
			throw new Exception("Data final invalida.");
		}
	}

	// obtem a soma das vendas realizadas
	public String obterValor(String inicio, String fim) throws Exception {
		Float comissao = 0.00f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}
		// Imprime a data convertida

		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = vComissaoVenda.get(dates);

			if (objeto != null) {
				comissao += objeto;
			}
		}
		if (comissao != 0) {
			return String.format("%.2f", comissao);
		}
		return "0,00";
	}

	// Getter e setters

	public LocalDate getDiaDePagamento() {
		return diaDePagamento;
	}

	public void setDiaDePagamento(String string) throws Exception {
		LocalDate x = converterInicio(string);
		this.diaDePagamento = x.plusDays(14);
		return;
	}

	public String getRealSalario() {
		return realSalario;
	}

	public void setrealSalario(String realSalario) {
		Float salary = Float.parseFloat(realSalario.replace(",", "."));
		
		Integer salarioComissaoi = (int) (salary * 100);
		salary= salarioComissaoi / 100.0f;
		salary = (salary * 12.0f)/ 52.0f;
		salary *= 2.0f;
        DecimalFormat decimalFormatter = new DecimalFormat("#,##0.00");
        this.realSalario = decimalFormatter.format(salary);
        return;
	}
}