package Util;

import java.text.DecimalFormat;

public class convertValues {
	public static String retorneString(Double value){
		DecimalFormat df = new DecimalFormat("#,##0.00");
		return df.format(value);
	}
	public static Float retorneFloat(String value) {
		return Float.parseFloat(value.replace(",", "."));
	}
	
	public static Integer retorneInt(String value) {
		return Integer.parseInt(value);
	}
}
