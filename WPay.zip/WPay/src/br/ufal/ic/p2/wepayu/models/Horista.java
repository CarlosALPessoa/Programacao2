package br.ufal.ic.p2.wepayu.models;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class Horista extends Empregado {
	//Horistas lancamento cartão
	private Map<String, String> horasTrabalhadas = new LinkedHashMap<>();

	// CONSTRUTOR
	public Horista(String nome, String endereco, String tipo, String salario){
		super(nome, endereco, tipo, salario);
		this.diaPaga = "";
	}
	
	/*
	 * 
	 * GETTERS E SETTERS
	 * 
	 * */	
	@Override
	public void setDiaPaga(String diaPaga) {
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		 LocalDate temp = LocalDate.parse(diaPaga, formatter).plusDays(7);	
		 DayOfWeek diaSemana = temp.getDayOfWeek();
		 if(diaSemana == DayOfWeek.SATURDAY) {
			 temp = temp.minusDays(1);
		 }
		 if(diaSemana == DayOfWeek.SUNDAY) {
			 temp = temp.minusDays(2);
		 }
		this.diaPaga = temp.format(formatter);
	}
	
	public void setHorasTrabalhadas(String data, String horas) {
		this.horasTrabalhadas.put(data, horas);
		if(this.diaPaga.isEmpty() ) {
			setDiaPaga(data);
		}
	}
	
	public Map<String, String> getHorasTrabalhadas() {
		return horasTrabalhadas;
	}
	
	/*
	 * 
	 * Funções
	 * 
	 * */
	
	/*/ Retorna totalFolha
	public Float PFolhaSemanal(String data) throws Exception {

		// Pega data final para conferir se é um dia de pagamento para o horista
		LocalDate dataFim = convertData.converterFim(data);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		// Se o funcionario lançou cartão entra, caso nao cancela o retorno do salário
		// semanal
		LocalDate diadePagamento;
		if (getDiaPaga() != null) {
			diadePagamento = LocalDate.parse(getDiaPaga(), formatter);
		} else {
			return 0.00f;
		}

		// Usadas para somar as horas * salário
		Float salarioNormal = 0.00f;
		Float salarioExtra = 0.00f;

		// Percorre procurando dias de pagamento
		while (diadePagamento.isBefore(dataFim) || diadePagamento.equals(dataFim)) {
			if (diadePagamento.equals(dataFim)) {
				diadePagamento = diadePagamento.minusDays(6);
				// Percorre os dias para pegar as horas diarias
				// Converte a data inicial da semana de pagamento
				dataFim = dataFim.plusDays(1);
				String diaObterInicial = diadePagamento.format(formatter);
				String diaObterFinal = dataFim.format(formatter);

				String horasNormais = hourWorks(diaObterInicial, diaObterFinal);
				String horasExtras = extrasHoras(diaObterInicial, diaObterFinal);

				salarioNormal = Float.parseFloat(getSalario().replace(",", ".")) * Float.parseFloat(horasNormais);
				salarioExtra = (float) ((Float.parseFloat(getSalario().replace(",", ".")) * 1.5)
						* Float.parseFloat(horasExtras.replace(",", ".")));

				setDiaPaga(data);
				// System.out.println(salarioNormal + salarioExtra + "Aqui soma");
				return (float) salarioNormal + salarioExtra;
			}
			diadePagamento = diadePagamento.plusDays(7); // Adiciona mais 7 dias à data atual
		}
		return 0.0f;
	}*/
}