package Exceptions;

public class AtributoNaoExiste extends Exception{
	private static final long serialVersionUID = 1L;

	public AtributoNaoExiste() {
		super("Atributo nao existe.");
	}
}
