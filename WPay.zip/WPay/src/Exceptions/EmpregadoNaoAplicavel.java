package Exceptions;

public class EmpregadoNaoAplicavel extends Exception {
	private static final long serialVersionUID = 1L;

	public EmpregadoNaoAplicavel() {
		super("Tipo nao aplicavel.");
	}
}
