package Util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Exceptions.DataInvalida;

public class convertData {
	
	
	
	public static LocalDate converterFim(String fim) throws DataInvalida{
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate dtf = LocalDate.parse(fim, formatter);
			if (Validadores.validarData(fim)) {
				return dtf;
			} else {
				throw new DataInvalida("Data final");
			}
		} catch (Exception e) {
			throw new DataInvalida("Data final");
		}
	}
	
	public static LocalDate converterInicio(String inicio) throws DataInvalida {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		try {
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new DataInvalida("Data inicial");
		}
	}	
}
