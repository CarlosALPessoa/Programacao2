package Exceptions;

public class valorTaxaP extends Exception {
	private static final long serialVersionUID = 1L;

	public valorTaxaP() {
		super("Valor deve ser positivo.");
	}
}
