package br.ufal.ic.p2.wepayu;

import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import br.ufal.ic.p2.wepayu.models.Comissionado;
import br.ufal.ic.p2.wepayu.models.Empregado;
import br.ufal.ic.p2.wepayu.models.Horista;
import br.ufal.ic.p2.wepayu.models.Sindicalizado;

public class Facade implements ServicosEmpregado {
	public static String arq = "src/arquivosTxt/emps_data.txt";
	static Map<String, Empregado> emps = new LinkedHashMap<>();

	// Escreve a folha de pagamento
	@SuppressWarnings("resource")
	public void rodaFolha(String data, String saida) throws Exception {
		String tfolha = totalFolha(data);
		escreverArquivo.escrita(data, saida, tfolha);
		return;
	}

	// Pega o total da folha
	public String totalFolha(String data) throws Exception {
		Float totalFolha = 0.00f;

		for (Empregado emp : emps.values()) {
			if (emp.getTipo().equals("horista")) {
				if (emp instanceof Horista) {
					Horista hr = (Horista) emp;
					totalFolha += hr.PFolhaSemanal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado hr = (Sindicalizado) emp;
					totalFolha += hr.PagamentoFolha(data);
				}
			} else if (emp.getTipo().equals("comissionado")) {
				if (emp instanceof Comissionado) {
					Comissionado comis = (Comissionado) emp;
					totalFolha += comis.pFolhaQuinzenal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado sindC = (Sindicalizado) emp;
					totalFolha += sindC.pFolhaQuinzenal(data);
				}
			} else if (emp.getTipo().equals("assalariado")) {
				if (emp instanceof Empregado) {
					totalFolha += emp.pFolhaMes(data);
				}
			}
		}
		DecimalFormat formato = new DecimalFormat("#,##0.00");
		String totalFolhas = formato.format(totalFolha);
		String totalFolhas2 = totalFolhas.replaceAll("\\.", "");
		return totalFolhas2;
	}

	// Para sindicalizados
	public void lancaTaxaServico(String membro, String data, String valor) throws Exception {
		if (membro.isEmpty() || membro == null) {
			throw new Exception("Identificacao do membro nao pode ser nula.");
		}

		for (Empregado emp : emps.values()) {
			if (emp instanceof Sindicalizado) {
				Sindicalizado id = (Sindicalizado) emp;
				if (id.getIdSind().equals(membro)) {
					Float taxa = Float.parseFloat(valor.replace(",", "."));
					if (taxa < 0 || taxa == 0) {
						throw new Exception("Valor deve ser positivo.");
					}
					id.registrarTaxaServico(data, taxa);
					return;
				}
			}
		}
		throw new Exception("Membro nao existe.");
	}

	public String getTaxasServico(String emp, String dataI, String dataF) throws Exception {
		validar(emp);
		if (emps.get(emp) instanceof Sindicalizado) {
			Sindicalizado id = (Sindicalizado) emps.get(emp);
			return id.obterTaxaComissao(dataI, dataF);
		}
		throw new Exception("Empregado nao eh sindicalizado.");
	}

	// Alterar forma de pagamento #6
	public void alteraEmpregado(String emp, String atributo, String valor1, String banco, String agencia,
			String contaCorrente) throws Exception {
		validar(emp);

		validarParametro(banco, "Banco");
		validarParametro(agencia, "Agencia");
		validarParametro(contaCorrente, "Conta corrente");

		switch (atributo) {
		case "metodoPagamento":
			emps.get(emp).setMetododePagamento(valor1);
			emps.get(emp).setBanco(banco);
			emps.get(emp).setAgencia(agencia);
			emps.get(emp).setCc(contaCorrente);
			return;
		default:
			throw new IllegalArgumentException("Atributo invalido.");
		}
	}

	// Alteracao para sindicalizado com detalhamento #5
	public void alteraEmpregado(String emp, String atributo, String valor, String valor1, String valor2)
			throws Exception {
		// Empregado, atributo, se é sindicalizado, id do sindicato, taxa do sindicato
		validar(emp);

		if (valor1.isEmpty() || valor1 == null) {
			throw new Exception("Identificacao do sindicato nao pode ser nula.");
		}
		validarValorNum(valor2, "Taxa sindical");

		switch (atributo) {
		case "sindicalizado": {
			if (valor.equals("true")) {
				Empregado id = emps.get(emp);

				for (Empregado s : emps.values()) {
					// percorre procurando pelos sindicalizados
					if (s instanceof Sindicalizado) {

						Sindicalizado outroSind = (Sindicalizado) s;
						// Se o membro for igual nao atribui a lista de empregados
						if (outroSind.getIdSind().equals(valor1)) {
							throw new Exception("Ha outro empregado com esta identificacao de sindicato");
						}
					}
				}

				Sindicalizado sind = new Sindicalizado(id.getNome(), id.getEndereco(), id.getTipo(), id.getSalario(),
						valor, id.getMetododePagamento(), id.getBanco(), id.getAgencia(), id.getCc(), valor1, valor2);
				if (id.getTipo().equals("comissionado")) {
					sind.setComissao(id.getComissao());
				}
				emps.put(emp, sind);
				return;
			}
		}
		default:
			throw new IllegalArgumentException("Atributo invalido.");
		}
	}

	// Altera atributos #4 Comissionado e Horista
	public void alteraEmpregado(String emp, String atributo, String valor, String valor1) throws Exception {
		validar(emp);
		switch (atributo) {
		case "tipo":
			Empregado id = emps.get(emp);

			if (valor.equals("horista")) {
				Horista hr = new Horista(id.getNome(), id.getEndereco(), valor, valor1);
				emps.put(emp, hr);
				return;
			}
			Comissionado comis = new Comissionado(id.getNome(), id.getEndereco(), valor, id.getSalario(), valor1);
			emps.put(emp, comis);

			return;
		default:
			throw new Exception("Atributo nao existe.");
		}
	}

	// Altera atributos simples #3
	public void alteraEmpregado(String emp, String atributo, String valor) throws Exception {
		validar(emp);

		switch (atributo) {
		// Padrao Empregado
		case "nome":
			validarParametro(valor, "Nome");
			emps.get(emp).setNome(valor);
			return;

		case "endereco":
			validarParametro(valor, "Endereco");
			emps.get(emp).setEndereco(valor);
			return;
		case "tipo":
			validarParametro(valor, "Tipo");
			emps.get(emp).setTipo(valor);
			return;
		case "salario":
			validarSalarioNum(valor);
			emps.get(emp).setSalario(valor);
			return;
		// Fim Padrão Empregado

		case "sindicalizado": {
			if (valor.equals("false") || valor.equals("true")) {
				emps.get(emp).setSindicalizado(valor);
				return;
			} else {
				throw new Exception("Valor deve ser true ou false.");
			}
		}
		case "comissao":
			if (emps.get(emp) instanceof Comissionado) {
				validarValorNum(valor, "Comissao");
				emps.get(emp).setComissao(valor);
				return;
			} else {
				throw new Exception("Empregado nao eh comissionado.");
			}
		case "metodoPagamento":
			if (valor.equals("emMaos") || valor.equals("banco") || valor.equals("correios")) {
				emps.get(emp).setMetododePagamento(valor);
				return;
			}
			throw new Exception("Metodo de pagamento invalido.");
		default:
			throw new IllegalArgumentException("Atributo nao existe.");
		}
	}

	// Base programa

	public void zerarSistema() {
		emps.clear();
	}

	public void encerrarSistema() {
		return;
	}

	// Empregado por nome
	public String getEmpregadoPorNome(String nome, String indice) throws Exception {
		Integer id = Integer.parseInt(indice);

		for (Map.Entry<String, Empregado> emp : emps.entrySet()) {
			if (emp.getValue().getNome().contains(nome)) {
				id -= 1;
				if (id == 0) {
					return emp.getKey();
				}
			}
		}
		throw new Exception("Nao ha empregado com esse nome.");
	}

	// Consultar por Atributo
	public String getAtributoEmpregado(String emp, String atributo) throws Exception {
	
		validar(emp);

		Empregado id = emps.get(emp);
		switch (atributo) {
		case "nome":
			return emps.get(emp).getNome();
		case "endereco":
			return emps.get(emp).getEndereco();
		case "tipo":
			return emps.get(emp).getTipo();
		case "salario":
			return emps.get(emp).getSalario();
		case "sindicalizado":
			return emps.get(emp).getSindicalizado();
		case "comissao":
			if (emps.get(emp) instanceof Comissionado) {
				return emps.get(emp).getComissao();
			}
			throw new Exception("Empregado nao eh comissionado.");

		case "idSindicato":
			if (emps.get(emp) instanceof Sindicalizado) {
				Sindicalizado s = (Sindicalizado) emps.get(emp);
				return s.getIdSind();
			}
			throw new Exception("Empregado nao eh sindicalizado.");
		case "taxaSindical":
			if (emps.get(emp) instanceof Sindicalizado) {
				Sindicalizado s = (Sindicalizado) emps.get(emp);
				return s.getTaxaSindical();
			}
			throw new Exception("Empregado nao eh sindicalizado.");
		case "metodoPagamento":
			return id.getMetododePagamento();
		case "banco":
			if (id.getBanco().isEmpty() || id.getBanco() == null) {
				throw new Exception("Empregado nao recebe em banco.");
			}
			return id.getBanco();
		case "agencia":
			if (id.getAgencia().isEmpty() || id.getAgencia() == null) {
				throw new Exception("Empregado nao recebe em banco.");
			}
			return id.getAgencia();
		case "contaCorrente":
			if (id.getCc().isEmpty() || id.getCc() == null) {
				throw new Exception("Empregado nao recebe em banco.");
			}
			return id.getCc();
		default:
			throw new Exception("Atributo nao existe.");
		}

	}

	@SuppressWarnings("static-access")
	public String criarEmpregado(String nome, String endereco, String tipo, String salario) throws Exception {
		validarParametro(nome, "Nome");
		validarParametro(endereco, "Endereco");

		if ("comissionado".equals(tipo)) {
			throw new Exception("Tipo nao aplicavel.");
		} else {
			validarParametro(tipo, "Tipo");
		}

		validarSalarioNum(salario);

		if (tipo.equals("horista")) {
			Horista emp = new Horista(nome, endereco, tipo, salario);
			String id = gerarID();
			this.emps.put(id, emp);
			return id;
		} else {
			Empregado emp = new Empregado(nome, endereco, tipo, salario);
			String id = gerarID();
			this.emps.put(id, emp);
			return id;
		}
	}

	// Excluir do Map
	public String removerEmpregado(String empr) throws Exception {
		if (!empr.isEmpty() && empr != null) {
			validar(empr);
			for (Map.Entry<String, Empregado> emp : emps.entrySet()) {
				if (empr.equals(emp.getKey())) {
					emps.keySet().remove(empr);
					return empr;
				}
			}

		} else {
			throw new Exception("Identificacao do empregado nao pode ser nula.");
		}
		throw new Exception("Empregado nao existe.");
	}

	// Horistas funcoes
	public void lancaCartao(String emp, String data, String horas) throws Exception {
		// Validacao
		validar(emp);
		Float hr = Float.parseFloat(horas.replace(",", "."));
		if (hr < 0 || hr == 0) {
			throw new Exception("Horas devem ser positivas.");
		}

		// Setter
		if (emps.get(emp).getTipo().equals("horista")) {
			if (emps.get(emp).getSindicalizado().equals("false")) {
				Horista id = (Horista) emps.get(emp);
				id.registrarHorasTrabalhadas(data, hr);
				return;
			} else if (emps.get(emp).getSindicalizado().equals("true")) {
				Sindicalizado id = (Sindicalizado) emps.get(emp);
				id.registrarHorasTrabalhadas(data, hr);
				return;
			}
		}

		throw new Exception("Empregado nao eh horista.");
	}

	public String getHorasExtrasTrabalhadas(String emp, String inicial, String fim) throws Exception {
		validar(emp);

		if (emps.get(emp).getTipo().equals("horista")) {
			Horista id = (Horista) emps.get(emp);
			return id.extrasHoras(inicial, fim);
		}
		throw new Exception("Empregado nao eh horista.");
	}

	public String getHorasNormaisTrabalhadas(String emp, String dataInicio, String dataFinal) throws Exception {
		validar(emp);
		if (emps.get(emp).getTipo().equals("horista")) {
			Horista id = (Horista) emps.get(emp);
			String algo = id.obterHorasNormaisTrabalhadas(dataInicio, dataFinal);
			System.out.println(algo + "após chamada");
			return algo;
		}
		throw new Exception("Empregado nao eh horista.");
	}

	// Fim diarista funcoes

	// Comissionado funcoes
	public String getVendasRealizadas(String emp, String dataI, String dataF) throws Exception {
		validar(emp);
		if (emps.get(emp).getTipo().equals("comissionado")) {
			Comissionado id = (Comissionado) emps.get(emp);
			return id.obterValor(dataI, dataF);
		}
		throw new Exception("Empregado nao eh comissionado.");
	}

	// Cria Empregado com comissao
	@SuppressWarnings("static-access")
	public String criarEmpregado(String nome, String endereco, String tipo, String salario, String nP)
			throws Exception {
		validarSalarioNum(salario);
		validarComissao(tipo, "Comissao", nP, salario);
		validarValorNum(nP, "Comissao");

		Comissionado emp = new Comissionado(nome, endereco, tipo, salario, nP);
		String id = gerarID();

		emps.put(id, emp);
		return id;
	}

	public void lancaVenda(String emp, String dati, String valor) throws Exception {
		validar(emp);
		Float paga = Float.parseFloat(valor.replace(",", "."));
		if (paga < 0 || paga == 0) {
			throw new Exception("Valor deve ser positivo.");
		}

		if (emps.get(emp).getTipo().equals("comissionado")) {
			if (emps.get(emp).getSindicalizado().equals("false")) {
				Comissionado id = (Comissionado) emps.get(emp);
				id.registrarValor(dati, paga);
				return;
			} else if (emps.get(emp).getSindicalizado().equals("true")) {
				Sindicalizado id = (Sindicalizado) emps.get(emp);
				id.registrarValor(dati, paga);
				return;
			}

		}
		throw new Exception("Empregado nao eh comissionado.");
	}

	// Validar parametro tipo == string
	public void validarParametro(String atributo, String tipoatributo) throws Exception {
		if (atributo == null || atributo.isEmpty()) {
			throw new Exception(tipoatributo + " nao pode ser nulo.");
		}

		if (tipoatributo == "Tipo") {
			if (!"horista".equals(atributo) && !"assalariado".equals(atributo)) {
				throw new Exception("Tipo invalido.");
			}
		}
		return;
	}

	private void validarSalarioNum(String salario) throws Exception {
		try {
			if (salario == null || salario.isEmpty()) {
				throw new Exception("Salario nao pode ser nulo.");
			}
			float salary = Float.parseFloat(salario.replace(",", "."));
			if (salary < 0) {
				throw new Exception("Salario deve ser nao-negativo.");
			}
			return;

		} catch (NumberFormatException e) {
			throw new Exception("Salario deve ser numerico.");
		}
	}

	private void validarComissao(String tipo, String tipoatributo, String nP, String salario) throws Exception {
		if (tipo.equals("comissionado") && nP == null || tipo.equals("comissionado") && nP.isEmpty()) {
			throw new Exception(tipoatributo + " nao pode ser nula.");
		}
		if (!"comissionado".equals(tipo) && nP != null || nP.isEmpty()) {
			throw new Exception("Tipo nao aplicavel.");
		}
		if (tipo == null || tipo.isEmpty()) {
			throw new Exception(tipoatributo + " nao pode ser nula.");
		}
		return;
	}

	// confere o parametro de valorComissao
	private void validarValorNum(String nP, String tipoAtributo) throws Exception {
		try {
			if (nP == null || nP.isEmpty()) {
				throw new Exception(tipoAtributo + " nao pode ser nula.");
			}
			float salary = Float.parseFloat(nP.replace(",", "."));
			if (salary < 0) {
				throw new Exception(tipoAtributo + " deve ser nao-negativa.");
			}
			return;
		} catch (NumberFormatException e) {
			throw new Exception(tipoAtributo + " deve ser numerica.");
		}
	}

	// Validador de empregado
	public void validar(String emp) throws Exception {
		if (emp.isEmpty() || emp == null) {
			throw new Exception("Identificacao do empregado nao pode ser nula.");
		}
		try {
			for (Map.Entry<String, Empregado> empregado : emps.entrySet()) {
				if (emp.equals(empregado.getKey())) {
					return;
				}
			}
			throw new Exception("Empregado nao existe.");
		} catch (Exception e) {
			throw new Exception("Empregado nao existe.");
		}
	}

	private String gerarID() {
		return UUID.randomUUID().toString();
	}
}
