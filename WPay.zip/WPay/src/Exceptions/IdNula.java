package Exceptions;

public class IdNula extends Exception {
	private static final long serialVersionUID = 1L;

	public IdNula() {
		super("Identificacao do empregado nao pode ser nula.");
	}
}
