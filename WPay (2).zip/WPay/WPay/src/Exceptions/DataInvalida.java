package Exceptions;

public class DataInvalida extends Exception{
	private static final long serialVersionUID = 1L;

	public DataInvalida(String tipo) {
		super(tipo + " invalida.");
	}
}
