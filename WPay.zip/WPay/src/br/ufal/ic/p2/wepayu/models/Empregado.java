package br.ufal.ic.p2.wepayu.models;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

public class Empregado {
	private String nome;
	private String endereco;
	private String tipo;
	private String salary;

	//Sindicalizados
	private String sindicalizado = "false";
	private String idSindicato;
	private String txSindical;
	private Map<String, String> taxaServico = new LinkedHashMap<String, String>();
	
	//Informações de pagamento
	private String metododePagamento = "emMaos";
	private String banco = "";
	private String agencia = "";
	private String cc = "";
	
	protected LocalDate diaPaga = LocalDate.parse("1/1/2015");

	//Construtores
	public void setMetododePagamento(String metododePagamento) {
		this.metododePagamento = metododePagamento;
		return;
	}

	public Empregado(String nome, String endereco, String tipo, String salario){
		this.nome = nome;
		this.endereco = endereco;
		this.tipo = tipo;
		this.salary = setSalario(salario);
	}
	
	public String setSalario(String salario) {
		float num = Float.parseFloat(salario.replace(",", "."));
		this.salary = String.format("%.2f", num);
		return this.salary;
	}

	public String getSindicalizado() {
		return sindicalizado;
	}

	public void setSindicalizado(String sindicalizado) {
		this.sindicalizado = sindicalizado;
		return;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
		return;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
		return;
	}

	public String getSalario() {
		return this.salary;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
		return;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
		return;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
		return;
	}

	public String getMetododePagamento() {
		return metododePagamento;
	}

	public String getIdSindicato() {
		return idSindicato;
	}

	public void setIdSindicato(String idSindicato) {
		this.idSindicato = idSindicato;
	}

	public String getTxSindical() {
		return txSindical;
	}

	public void setTxSindical(String txSindical) {
		this.txSindical = txSindical;
	}

	public Map<String, String> getTaxaServico() {
		return taxaServico;
	}

	public void setTaxaServico(String data, String valor) {
		this.taxaServico.put(data, valor);
	}

	public LocalDate getDiaPaga() {
		return diaPaga;
	}

	public void setDiaPaga(LocalDate diaPaga) {
		this.diaPaga = diaPaga;
	}
}
