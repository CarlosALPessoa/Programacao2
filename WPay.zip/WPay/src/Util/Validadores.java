package Util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;

import Exceptions.AtributoNulo;
import Exceptions.EmpregadoNaoExiste;
import Exceptions.IdSindEmpNula;
import Exceptions.valorTaxaP;
import br.ufal.ic.p2.wepayu.auxFacade;
import br.ufal.ic.p2.wepayu.models.Empregado;

public class Validadores {
	
	public static void validar(String emp) throws IdSindEmpNula, EmpregadoNaoExiste {
		if (emp.isEmpty() || emp == null) {
			throw new IdSindEmpNula("empregado");
		}
		for (Map.Entry<String, Empregado> empregado : auxFacade.empss.entrySet()) {
			if (emp.equals(empregado.getKey())) {
				return;
			}
		}
		throw new EmpregadoNaoExiste("Empregado");		
	}
	
	public static void validarParametro(String valor, String tipo) throws AtributoNulo {
		if (valor == null || valor.isEmpty()) {
			throw new AtributoNulo(tipo);
		}
	}
	
	public static void validarComissao(String valor) throws Exception {
		if (valor == null || valor.isEmpty()) {
			throw new Exception("Comissao nao pode ser nula.");
		}
		try {
			Float coms = Float.parseFloat(valor.replaceAll(",", "."));
			
			if(coms < 0) {
				throw new Exception("Comissao deve ser nao-negativa.");
			}
		} catch(NumberFormatException e) {
			throw new Exception("Comissao deve ser numerica.");
		}
	}
	
	

	public static void validarNum(String valor, String tipo) throws Exception {
		if (valor.isEmpty()) {
			throw new Exception(tipo + " nao pode ser nula.");
		}
		try {
			Float coms = Float.parseFloat(valor.replaceAll(",", "."));
			
			if(coms < 0) {
				if(tipo.equals("Taxa sindical")) {
					throw new Exception(tipo + " deve ser nao-negativa.");
				}
				throw new Exception(tipo + " deve ser positiva.");
			}
		} catch(NumberFormatException e) {
			throw new Exception(tipo + " deve ser numerica.");
		}
	}

	public static void validarSalario(String salario) throws Exception {
		if (salario.isEmpty()) {
			throw new Exception("Salario nao pode ser nulo.");
		}
		try {
			Float coms = Float.parseFloat(salario.replaceAll(",", "."));
			
			if(coms < 0) {
				throw new Exception("Salario deve ser nao-negativo.");
			}
		} catch(NumberFormatException e) {
			throw new Exception("Salario deve ser numerico.");
		}
	}

	public static void validarHour(String horas, String string) throws Exception {
		if(horas.isEmpty()) {
			throw new Exception("Data nao pode ser nula.");
		}
		Float hr = Float.parseFloat(horas.replaceAll(",", "."));
		
		if(hr <= 0) {
			throw new Exception("Horas devem ser positivas.");
		}
	}
	
	public static Boolean validarData(String dtf) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		
		sdf.setLenient(false); // Impede interpretações flexíveis, ou seja, datas inválidas serão rejeitadas

		try {
			sdf.parse(dtf);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static void idSindicato(String idSind) throws IdSindEmpNula {
		if (idSind.isEmpty()) {
			throw new IdSindEmpNula("sindicato");
		}
	}

	public static void validarMembro(String membro) throws IdSindEmpNula {
		if(membro.isEmpty()) {
			throw new IdSindEmpNula("membro");
		}
	}

	public static void validarTaxaValor(String valor) throws valorTaxaP {
		Float valort = Float.parseFloat(valor.replaceAll(",", "."));
		
		if(valort <= 0) {
			throw new valorTaxaP();
		}
	}
}
