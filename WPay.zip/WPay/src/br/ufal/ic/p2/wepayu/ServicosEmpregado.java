package br.ufal.ic.p2.wepayu;

public interface ServicosEmpregado {
	//void zerarSistema();
	//void encerrarSistema();
	//void lancaCartao(String emp, String data, String horas) throws Exception;
	//void lancaTaxaServico(String membro, String data, String valor) throws Exception;
	//void alteraEmpregado(String emp, String atributo, String valor1) throws Exception;
	//void alteraEmpregado(String emp, String atributo, String valor1, String valor2, String valor3) throws Exception;
	
	//Construcao empregado
	String criarEmpregado(String nome, String endereco, String tipo, String salario) throws Exception;
	String criarEmpregado(String nome, String endereco, String tipo, String salario, String comissao) throws Exception ;

	String removerEmpregado(String empr) throws Exception;
	
	
	//Getters
	String getVendasRealizadas(String emp, String dataInicial, String dataFinal) throws Exception;
	String getEmpregadoPorNome(String nome, String indice) throws Exception;
	String getAtributoEmpregado(String emp, String atributo) throws Exception;
	String getHorasNormaisTrabalhadas(String emp, String dataInicial, String dataFinal) throws Exception;
	String getHorasExtrasTrabalhadas(String emp, String dataInicial, String dataFinal) throws Exception;
	
}
