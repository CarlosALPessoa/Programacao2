package Exceptions;

public class EmpregadoNaoExiste extends Exception {
	private static final long serialVersionUID = 1L;

	public EmpregadoNaoExiste(String tipo) {super(tipo + " nao existe.");}
}
