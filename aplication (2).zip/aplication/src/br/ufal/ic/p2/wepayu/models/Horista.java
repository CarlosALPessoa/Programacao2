package br.ufal.ic.p2.wepayu.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class Horista extends Empregado {
	private Map<String, Float> horasTrabalhadas = new LinkedHashMap<>();
	private String datePag;

	// Construtor
	public Horista(String nome, String endereco, String tipo, String salario) throws Exception {
		super(nome, endereco, tipo, salario);
	}

	// Retorna totalFolha
	public Float PFolhaSemanal(String data) throws Exception {

		// Pega data final para conferir se é um dia de pagamento para o horista
		LocalDate dataFim = converterFim(data);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		// Se o funcionario lançou cartão entra, caso nao cancela o retorno do salário
		// semanal
		LocalDate diadePagamento;
		if (getdatePag() != null) {
			diadePagamento = LocalDate.parse(getdatePag(), formatter);
		} else {
			return 0.00f;
		}

		// Usadas para somar as horas * salário
		Float salarioNormal = 0.00f;
		Float salarioExtra = 0.00f;

		// Percorre procurando dias de pagamento
		while (diadePagamento.isBefore(dataFim) || diadePagamento.equals(dataFim)) {
			if (diadePagamento.equals(dataFim)) {
				diadePagamento = diadePagamento.minusDays(6);
				// Percorre os dias para pegar as horas diarias
				// Converte a data inicial da semana de pagamento
				dataFim = dataFim.plusDays(1);
				String diaObterInicial = diadePagamento.format(formatter);
				String diaObterFinal = dataFim.format(formatter);

				String horasNormais = hourWorks(diaObterInicial, diaObterFinal);
				String horasExtras = extrasHoras(diaObterInicial, diaObterFinal);

				salarioNormal = Float.parseFloat(getSalario().replace(",", ".")) * Float.parseFloat(horasNormais);
				salarioExtra = (float) ((Float.parseFloat(getSalario().replace(",", ".")) * 1.5)
						* Float.parseFloat(horasExtras.replace(",", ".")));

				setdatePag(data);
				// System.out.println(salarioNormal + salarioExtra + "Aqui soma");
				return (float) salarioNormal + salarioExtra;
			}
			diadePagamento = diadePagamento.plusDays(7); // Adiciona mais 7 dias à data atual
		}
		return 0.0f;
	}

	// Registro de hora

	public void registrarHorasTrabalhadas(String data, Float horas) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);

			
			this.horasTrabalhadas.put(data, horas);

			if (datePag == null) {
				LocalDate diadePagamento = LocalDate.parse(data, formatter);
				diadePagamento = diadePagamento.plusDays(6);
				data = diadePagamento.format(formatter);
				setdatePag(data);
			}
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}
	//// fim registro

	private LocalDate converterInicio(String inicio) throws Exception {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		try {
			// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new Exception("Data inicial invalida.");
		}
	}

	public Boolean validarData(String dtf) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		sdf.setLenient(false); // Impede interpretações flexíveis, ou seja, datas inválidas serão rejeitadas

		try {
			sdf.parse(dtf);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	private LocalDate converterFim(String fim) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate dtf = LocalDate.parse(fim, formatter);
			if (validarData(fim)) {
				return dtf;
			} else {
				throw new Exception("Data final invalida.");
			}
		} catch (Exception e) {
			throw new Exception("Data final invalida.");
		}
	}

	public String extrasHoras(String inicio, String fim) throws Exception {
		Float horasExtras = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);
		// Imprime a data convertida
		
		if(horasTrabalhadas.isEmpty() || horasTrabalhadas == null) {
			return "0";
		}
		
		while (!datai.equals(dataf)) {
			String dates = formatter.format(datai);
			
			Float objeto = 0.0f;
			if(horasTrabalhadas.containsKey(dates)) {
				objeto = horasTrabalhadas.get(dates);
			}
			
			if (objeto != null) {
				if (objeto > 8 && objeto >= 0) {
					horasExtras += objeto - 8;				
				}
			}
			datai = datai.plusDays(1);
		}
		if(horasExtras % 1 != 0) {
	        return String.format("%.1f", horasExtras);
		}
		else {
			return String.format("%d", Float.valueOf(horasExtras).intValue());
		}
	}

	public String hourWorks(String inicio, String fim) throws Exception {
		Float normalHr = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		
		LocalDate datai = converterInicio(inicio);
		LocalDate dataf = converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior aa data final.");
		}
		
		while(datai.isBefore(dataf)) {			
			String dataPegaHr = formatter.format(datai);
			Float horas = 0.0f;
			if(horasTrabalhadas.containsKey(dataPegaHr)) {
				horas = horasTrabalhadas.get(dataPegaHr);
			}
			
			if (horas > 8.0f) {
				normalHr += 8;
			} else if (horas <= 8.0f && horas > 0.0f) {
				normalHr += horas;
			}
			
			datai = datai.plusDays(1);
		}
		return String.format("%d", Float.valueOf(normalHr).intValue());
	}

	@Override
	public int hashCode() {
		return Objects.hash(horasTrabalhadas);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Horista other = (Horista) obj;
		return Objects.equals(horasTrabalhadas, other.horasTrabalhadas);
	}

	public Map<String, Float> getHorasTrabalhadas() {
		return horasTrabalhadas;
	}

	public void setHorasTrabalhadas(Map<String, Float> horasTrabalhadas) {
		this.horasTrabalhadas = horasTrabalhadas;
	}

	public String getDatePag() {
		return datePag;
	}

	public void setDatePag(String datePag) {
		this.datePag = datePag;
	}

	// Getter e setters
	public String getdatePag() {
		return this.datePag;
	}

	public void setdatePag(String datePag) {
		this.datePag = datePag;
		return;
	}
}