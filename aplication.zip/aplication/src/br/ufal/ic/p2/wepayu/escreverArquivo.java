package br.ufal.ic.p2.wepayu;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class escreverArquivo extends Facade{
	
	private static void padrao(BufferedWriter bufferEscrita) throws IOException {
		bufferEscrita.write("====================================");
		//sai dessa
		bufferEscrita.newLine();
		//sai do espaço
		bufferEscrita.newLine();
		bufferEscrita.write("===============================================================================================================================");
		bufferEscrita.newLine();
		return;
	}
	
	public static void escrita(String data, String saida, String tfolha) {
		try{
			//Criacao do caminho e do arquivo para salvar Folha
			String caminho = "src/arquivosTxt/" + File.separator + saida;
			File arquivo = new File(caminho);
			
			FileWriter escritor = new FileWriter(arquivo);
			BufferedWriter bufferEscrita = new BufferedWriter(escritor);
			
			//Experimento de escrita com total folha
			
			
			//Escrevendo no arquivo saida
				//Deixando a data como deseja-se
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");				
			LocalDate dateEscrita = LocalDate.parse(data, formatter);
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String dataEscrita = dateEscrita.format(formatter);
			bufferEscrita.write("FOLHA DE PAGAMENTO DO DIA " + dataEscrita);
			bufferEscrita.newLine();
			
			padrao(bufferEscrita);
			padraCabeçalhoHorista(bufferEscrita);
			bufferEscrita.newLine();
			
			
			bufferEscrita.close();
			return;
		} catch (IOException e) {
            // Trata qualquer exceção de E/S que possa ocorrer
            System.err.println("Erro ao criar o arquivo: " + e.getMessage());
            return;
        }
	}

	private static void padraCabeçalhoHorista(BufferedWriter bufferEscrita) throws IOException {
				bufferEscrita.write("===================== HORISTAS ================================================================================================");
				
				bufferEscrita.newLine();				
				bufferEscrita.write("===============================================================================================================================");
				
				bufferEscrita.newLine();
				bufferEscrita.write("Nome     | Horas | Extra | Salario | Bruto | Descontos | Salario Liquido | Metodo");
				bufferEscrita.newLine();
				bufferEscrita.write("==================================== ===== ===== ============= ========= =============== ======================================");
				return;
	}
}

