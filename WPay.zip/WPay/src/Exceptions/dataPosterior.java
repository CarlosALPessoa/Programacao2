package Exceptions;

public class dataPosterior extends Exception {
	private static final long serialVersionUID = 1L;

	public dataPosterior() {
		super("Data inicial nao pode ser posterior a data final.");
	}
}
