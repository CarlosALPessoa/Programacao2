package Exceptions;

public class NaoEhTipo extends Exception{
	public NaoEhTipo(String tipo) {
		super("Empregado nao eh " + tipo +".");
	}
}
