package br.ufal.ic.p2.wepayu;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import Exceptions.AtributoNaoExiste;
import Exceptions.AtributoNulo;
import Exceptions.DataInvalida;
import Exceptions.EmpregadoNaoAplicavel;
import Exceptions.EmpregadoNaoEncontrado;
import Exceptions.EmpregadoNaoExiste;
import Exceptions.IdSindEmpNula;
import Exceptions.NaoEhTipo;
import Exceptions.NaoRecebeBanco;
import Exceptions.TipoInvalido;
import Exceptions.dataPosterior;
import Exceptions.existeIdSindicato;
import Util.Validadores;
import Util.convertData;
import Util.convertValues;
import br.ufal.ic.p2.wepayu.models.Comissionado;
import br.ufal.ic.p2.wepayu.models.Empregado;
import br.ufal.ic.p2.wepayu.models.Horista;

public class auxFacade {
	public static Map<String, Empregado> empss = new LinkedHashMap<>();
	public static Map<String, String> emps = new LinkedHashMap<>();
	
	//Gerador de identificação unica
	private static String gerarID() {
		return UUID.randomUUID().toString();
	}	

	public static void limparRegistro() {
		empss.clear();
	}
	
	public static Integer totalUser(Map<String, Empregado> emps) {
		return emps.size();
	}

	//Empregado Comissionado
	public static String createEmpC(String nome, String endereco, String tipo, String salario, String comissao) throws Exception {
		if(!tipo.equals("comissionado")) {
			throw new EmpregadoNaoAplicavel();
		}
		
		Validadores.validarComissao(comissao);
		Validadores.validarParametro(nome, "Nome");
		Validadores.validarParametro(endereco, "Endereco");
		Validadores.validarSalario(salario);
		
		Comissionado emp = new Comissionado(nome, endereco, tipo, salario, comissao);
		String id = gerarID();		
		empss.put(id, emp);
		return id;
	}
	
	//Empregado Padrão
	public static String createEmpP(String nome, String endereco, String tipo, String salario) throws Exception {
		if(tipo.equals("comissionado")) {
			throw new EmpregadoNaoAplicavel();
		}		
		if(!tipo.equals("horista") && !tipo.equals("assalariado")) {
			throw new TipoInvalido("Tipo");
		}
		
		String id = gerarID();

		Validadores.validarParametro(nome, "Nome");
		Validadores.validarParametro(endereco, "Endereco");
		Validadores.validarSalario(salario);
		
		
		if(tipo.equals("horista")) {
			Horista emp = new Horista(nome, endereco, tipo, salario);
			empss.put(id, emp);
		}else {
			Empregado emp = new Empregado(nome, endereco, tipo, salario);
			empss.put(id, emp);
		}		
		return id;
	}
	
	//Busca o atributo do empregado
	public static String pesquisaPorAtributo(String emp, String atributo) throws Exception {
		Validadores.validar(emp);
		
		if(!empss.isEmpty()) {	
			switch (atributo) {
				case "nome" : 
					return empss.get(emp).getNome();
				case "endereco":
					return empss.get(emp).getEndereco();
				case "tipo":
					return empss.get(emp).getTipo();
				case "salario":
					return empss.get(emp).getSalario();
				case "sindicalizado":
					return empss.get(emp).getSindicalizado();
				
				case "comissao":
					if(empss.get(emp) instanceof Comissionado) {
						Comissionado coms = (Comissionado) empss.get(emp);
						return coms.getComissao();
					}
					else {
						throw new Exception("Empregado nao eh comissionado.");
					}
				case "metodoPagamento":
					return empss.get(emp).getMetododePagamento();
				case "banco":
					if(empss.get(emp).getBanco().isEmpty()) {
						throw new NaoRecebeBanco();
					}
					return empss.get(emp).getBanco();
				case "agencia":
					if(empss.get(emp).getAgencia().isEmpty()) {
						throw new NaoRecebeBanco();
					}
					return empss.get(emp).getAgencia();
				case "contaCorrente":
					if(empss.get(emp).getCc().isEmpty()) {
						throw new NaoRecebeBanco();
					}
					return empss.get(emp).getCc();
				case "idSindicato":
					if(empss.get(emp).getIdSindicato() == null) {
						throw new NaoEhTipo("sindicalizado");
					}
					return empss.get(emp).getIdSindicato();
				case "taxaSindical":
					if(empss.get(emp).getTxSindical() == null) {
						throw new NaoEhTipo("sindicalizado");
					}
					DecimalFormat df= new DecimalFormat("#,##0.00");
					double value = Double.parseDouble(empss.get(emp).getTxSindical());
					String tx = df.format(value);
					return tx;
				}//Fim switch				
		}
		else {
			
		}
		throw new Exception("Atributo nao existe.");
	}

	//busca por nome
	public static String pesquisaPorNome(String nome, String indice) throws EmpregadoNaoEncontrado {
		Integer id = Integer.parseInt(indice);

		for (Map.Entry<String, Empregado> emp : empss.entrySet()) {
			if (emp.getValue().getNome().contains(nome)) {
				id -= 1;
				if (id == 0) {
					return emp.getKey();
				}
			}
		}
		throw new EmpregadoNaoEncontrado();
	}

	//remove do registro o empregado
	public static void removeEmp(String emp) throws Exception {
		Validadores.validar(emp);
		if (!empss.isEmpty()) {
			for (Map.Entry<String, Empregado> empr : empss.entrySet()) {
				if (empr.getKey().equals(emp)) {
					empss.keySet().remove(emp);
					return;
				}
			}

		} else {
			throw new IdSindEmpNula("empregado");
		}
		throw new EmpregadoNaoExiste("Empregado");
	}

	//Lanca as horas do dia especificado
	public static void cartaoPonto(String emp, String data, String horas) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
		Horista hr = (Horista) empss.get(emp);
	
		Validadores.validarHour(horas, "Horas");
		if(Validadores.validarData(data).equals(false)) {
			throw new Exception("Data invalida.");
		}
		
		hr.setHorasTrabalhadas(data, horas);
		empss.put(emp, hr);
	}
	
	//Retorna o total de horas normais trabalhadas
	public static String verHorasNormaisT(String emp, String dataInicio, String dataFinal) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
		
		Horista hr = (Horista) empss.get(emp);
		
		Float normalHr = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		
		LocalDate datai = convertData.converterInicio(dataInicio);
		LocalDate dataf = convertData.converterFim(dataFinal);

		if (!datai.isBefore(dataf) && !datai.equals(dataf)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}
		
		while(datai.isBefore(dataf)) {			
			String dataPegaHr = formatter.format(datai);
			Float horas = 0.0f;
			
			if(hr.getHorasTrabalhadas().containsKey(dataPegaHr)) {
				horas = Float.parseFloat(hr
						.getHorasTrabalhadas()
						.get(dataPegaHr)
						.replace(",", "."));
			}
			
			if (horas > 8.0f) {
				normalHr += 8;
			} else if (horas <= 8.0f && horas > 0.0f) {
				normalHr += horas;
			}
			
			datai = datai.plusDays(1);
		}
		return String.format("%d", Float.valueOf(normalHr).intValue());
	}

	//Retorna o total de horas extras trabalhadas
	public static String verHorasExtrasT(String emp, String inicial, String fim) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
		Float horasExtras = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = convertData.converterInicio(inicial);
		LocalDate dataf = convertData.converterFim(fim);		

		Horista hr = (Horista) empss.get(emp);
		
		if (!datai.isBefore(dataf) && !datai.equals(dataf)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}
		
		if(hr.getHorasTrabalhadas().isEmpty()) {
			return "0";
		}
		
		
		while (!datai.equals(dataf)) {
			String dates = formatter.format(datai);
			
			Float hrExtra = 0.0f;
			if(hr.getHorasTrabalhadas().containsKey(dates)) {
				hrExtra = Float.parseFloat(hr
						.getHorasTrabalhadas()
						.get(dates)
						.replace(",", "."));
			}
			
			if (hrExtra != null) {
				if (hrExtra > 8 && hrExtra >= 0) {
					horasExtras += hrExtra - 8;				
				}
			}
			datai = datai.plusDays(1);
		}
		if(horasExtras % 1 != 0) {
	        return String.format("%.1f", horasExtras);
		}
		else {
			return String.format("%d", Float.valueOf(horasExtras).intValue());
		}
	}

	public static void vendaComissao(String emp, String dati, String valor) throws Exception {
		Validadores.validar(emp);
		
		if(!empss.get(emp).getTipo().equals("comissionado")){
			throw new NaoEhTipo("comissionado");
		}
		
		Float paga = Float.parseFloat(valor.replace(",", "."));
		if (paga < 0 || paga == 0) {
			throw new Exception("Valor deve ser positivo.");
		}

		if (empss.get(emp) instanceof Comissionado) { 
				Comissionado cms = (Comissionado) empss.get(emp);
				cms.registrarValor(dati, Float.parseFloat(valor.replace(",", ".")));
				empss.put(emp, cms);				
				return;
		}
		throw new Exception("Empregado nao eh comissionado.");
	}

	public static String vendasPeriodo(String emp, String dataI, String dataF) throws Exception {
		Validadores.validar(emp);
		
		if (empss.get(emp).getTipo().equals("comissionado")) {
			if(empss.get(emp) instanceof Comissionado) {
				Comissionado id = (Comissionado) empss.get(emp);
				return id.obterValor(dataI, dataF);
			}
		}
		throw new NaoEhTipo("comissionado");
	}

	//Altera 6atributos
	public static void alteraPSindicalizado(String emp, String atributo, String valor, String idSind, String txSind) throws Exception{
		Validadores.validar(emp);
		Validadores.idSindicato(idSind);
		Validadores.validarNum(txSind, "Taxa sindical");
		
		if(atributo.equals("sindicalizado")) {
			if(valor.equals("true")) {
				//verifica se existe outro usuário com o mesmo id
				if(emps.containsKey(idSind)) {
					throw new existeIdSindicato();
				}
				
				empss.get(emp).setSindicalizado(valor);
				empss.get(emp).setTxSindical(txSind);
				empss.get(emp).setIdSindicato(idSind);
				emps.put(idSind, emp);
			}
		}
		else {
			Validadores.validarParametro(atributo, "Atributo");
		}
	}

	//Lanacmento de taxa para o funcionario sindicalizado
	public static void taxaParaServico(String membro, String data, String valor) throws Exception {
		Validadores.validarMembro(membro);
		
		if(Validadores.validarData(data).equals(false)) {
			throw new DataInvalida("Data");
		}
		
		if(emps.containsKey(membro)) {
			String emp = emps.get(membro);
			
			Validadores.validarTaxaValor(valor);
			
			empss.get(emp).setTaxaServico(data, valor);
		}else {
			throw new EmpregadoNaoExiste("Membro");
		}
	}

	public static String totalTaxasPeriodo(String emp, String dataI, String dataF) throws DataInvalida, dataPosterior, NaoEhTipo {
		if(empss.get(emp).getSindicalizado().equals("true")) {
			Map<String, String>taxasPeriodo = empss.get(emp).getTaxaServico();
			return obterValor(taxasPeriodo,dataI , dataF);
		}
		throw new NaoEhTipo("sindicalizado");
	}

	//Obtem o valor periodico da taxaServico
	private static String obterValor(Map<String, String> taxasPeriodo, String dataI, String dataF) throws DataInvalida, dataPosterior {
		Float total = 0.00f;
		
		DateTimeFormatter formt = DateTimeFormatter.ofPattern("d/M/yyyy");
		
		LocalDate datai = convertData.converterInicio(dataI);
		LocalDate dataf = convertData.converterFim(dataF); 
		
		if(dataf.isBefore(datai)) {
			throw new dataPosterior();
		}
		
		for(LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formt);
			
			//Evita valores nulos
			if(taxasPeriodo.containsKey(dates)) {
				Float value = Float.parseFloat(taxasPeriodo.get(dates).replace(",", "."));
				total += value;
			}
		}

        DecimalFormat decimalFormatter = new DecimalFormat("#,##0.00");
        String totalString = decimalFormatter.format(total);
		
		return totalString;
	}

	//Modifica os parametros comuns num empregado #3atributos
	public static void alteraAtributosEmp(String emp, String atributo, String valor) throws Exception {
		Validadores.validar(emp);
		
		switch (atributo) {
			case "nome":
				Validadores.validarParametro(valor, "Nome");
				empss.get(emp).setNome(valor);
				break;
			case "endereco":
				Validadores.validarParametro(valor, "Endereco");
				empss.get(emp).setEndereco(valor);
				break;
			case "tipo":
				if(!valor.equals("comissionado") && !valor.equals("horista") && !valor.equals("assalariado")) {
					throw new TipoInvalido("Tipo");
				}
				Validadores.validarParametro(valor, "Tipo");
				empss.get(emp).setTipo(valor);
				break;
			case "salario":
				Validadores.validarSalario(valor);
				empss.get(emp).setSalario(valor);
				break;
			case "sindicalizado":{
				if (valor.equals("false")) {
					if(emps.containsValue(emp)) {
						emps.remove(empss.get(emp).getIdSindicato());
					}
					empss.get(emp).setSindicalizado(valor);
					return;
				}
				else if(valor.equals("true")) {
					empss.get(emp).setSindicalizado(valor);
					return;
				} else {
					throw new Exception("Valor deve ser true ou false.");
				}
			}
			case "comissao":{
				Validadores.validarComissao(valor);
				
				if(empss.get(emp) instanceof Comissionado) {
					Comissionado cms = (Comissionado) empss.get(emp);
					cms.setComissao(valor);
					cms.setTipo("comissionado");
					empss.put(emp, cms);
				}else {
					throw new NaoEhTipo("comissionado");
				}
				break;
			}
			case "metodoPagamento":{
				if (valor.equals("emMaos") || valor.equals("banco") || valor.equals("correios")) {
					empss.get(emp).setMetododePagamento(valor);
					return;
				}
				throw new TipoInvalido("Metodo de pagamento");
			}
			default:
				throw new AtributoNaoExiste();				
		}
		return;
	}

	public static void alteraMetdsPaga(String emp, String atributo, String formaPaga, String banco, String agencia,
			String contaCorrente) throws IdSindEmpNula, EmpregadoNaoExiste, AtributoNulo, TipoInvalido {
		Validadores.validar(emp);
		Validadores.validarParametro(banco, "Banco");
		Validadores.validarParametro(agencia, "Agencia");
		Validadores.validarParametro(contaCorrente, "Conta corrente");
		
		if(atributo.equals("metodoPagamento")) {
			empss.get(emp).setMetododePagamento(formaPaga);
			empss.get(emp).setBanco(banco);
			empss.get(emp).setAgencia(agencia);
			empss.get(emp).setCc(contaCorrente);
			return;
		}
		
		throw new TipoInvalido("Atributo");
	}

	//Altera para horista/assalariado(falta implementar) 4 atributos
	public static void alteraTipoEmp(String emp, String atributo, String tipoEmp, String valor) throws Exception {
		Validadores.validar(emp);
		
		if(atributo.equals("tipo")) {
			switch (tipoEmp) {
			case "horista": {
				Horista hr = new Horista(empss.get(emp).getNome(), empss.get(emp).getEndereco(), tipoEmp, valor);
				empss.put(emp, hr);
				return;
			}
			case "comissionado":
				Comissionado cms = new Comissionado(empss.get(emp).getNome(),
					   	empss.get(emp).getEndereco(),
					   	tipoEmp,
						empss.get(emp).getSalario(), valor);
				empss.put(emp, cms);
				return;
			default:
				throw new AtributoNaoExiste();
			}
		}
	}

	public static String totalDespesas(String data) throws Exception {
		double totally = 0.00f;
		for(Map.Entry<String, Empregado> func : empss.entrySet()){
			String chave = func.getKey();
			
			if(empss.get(chave).getDiaPaga().equals(data)){
				
				if(empss.get(chave) instanceof Horista) {
					totally += totalDespesasHr(chave, data);
				}
			}
		}
		if(totally >= 0) {
			return convertValues.retorneString(totally);
		}
		return "0,00";
	}

	private static double totalDespesasHr(String chave, String data) throws Exception {
		DateTimeFormatter df = DateTimeFormatter.ofPattern("d/M/yyyy");
		LocalDate temp = LocalDate.parse(data, df).minusDays(7);
		String dataInicial = temp.format(df);
		
		double hrNormais = Double.parseDouble(verHorasNormaisT(chave, dataInicial, data).replace(",", "."));
		double hrExtras = Double.parseDouble(verHorasExtrasT(chave, dataInicial, data).replace(",", "."));
		
		//Convert o valor do salario para float
		float valorSalario = convertValues.retorneFloat(empss.get(chave).getSalario());
		double hrExtrasS = (valorSalario * 1.5) * hrExtras;
		double hrNormaisS = valorSalario * hrNormais;
		return hrNormaisS + hrExtrasS;
	}
	
	
	//Escreve o arquivo de saída para a Folha de pagamento.
	public static void relatorioFolha(String data, String saida) throws Exception {
		try {
			String caminho = "src/arquivosTxt/" + File.separator + saida;
			File arquivo = new File(caminho);
			
			FileWriter escritor = new FileWriter(arquivo);
			BufferedWriter bufferEscrita = new BufferedWriter(escritor);
			
			LocalDate dateEscrita = convertData.converterInicio(data);
			String dataFolha = convertData.convertparaLocalDate(dateEscrita);
			
			escritaCabeçalhoFolha(dataFolha, bufferEscrita);
			
			BufferedReader leitor = new BufferedReader(new FileReader("Util/CabeçalhoHorista.txt"));
			
			escritaCabeçalhoHorista(leitor, bufferEscrita);
			
			escreverHoristas(bufferEscrita, data);
			
		} catch(IOException e) {
			System.err.println("Ero ao criar o arquivo: " + e.getMessage());
		}
	}

	private static void escreverHoristas(BufferedWriter bufferEscrita, String data) throws Exception {
		int totalHr = 0;
		int totalHrExt = 0;
		float totalSalarioB = 0.0f;
		float totalDescont = 0.0f;
		float totalSLiq = 0.0f;
		
		for(Map.Entry<String, Empregado> emp : empss.entrySet()) {
			if(empss.get(emp.getKey()) instanceof Horista) {
				String chave = emp.getKey();
				Horista hr = (Horista) empss.get(emp.getKey());
				if(hr.getDiaPaga().equals(data)) {
					LocalDate dataInicial = convertData.converterInicio(data);
					DayOfWeek temp = dataInicial.getDayOfWeek();
					
					if(temp.equals(DayOfWeek.FRIDAY)) {
						dataInicial = dataInicial.minusDays(4);
					}else {
						dataInicial = dataInicial.minusDays(6);
					}
					String dtInicial = convertData.convertLocalDpString(dataInicial);
					dataInicial = dataInicial.plusDays(7);
					String dtFinal = convertData.convertLocalDpString(dataInicial);
					
					String extras = verHorasExtrasT(chave, dtInicial, dtFinal);
					String normais = verHorasNormaisT(chave, dtInicial, dtFinal);
					
					int somaHrTotais = convertValues.retorneInt(extras) + convertValues.retorneInt(normais);
					
					
					empss.get(chave).setDiaPaga(data);
				}
			}
		}
		
	}

	private static void escritaCabeçalhoHorista(BufferedReader leitor, BufferedWriter bufferEscrita) throws IOException {
		String linha;
        // Lê cada linha do arquivo de entrada
        while ((linha = leitor.readLine()) != null) {
            // Escreve a linha no arquivo de saída
            bufferEscrita.write(linha);
            bufferEscrita.newLine(); // Adiciona uma nova linha
        }
	}

	private static void escritaCabeçalhoFolha(String dataFolha, BufferedWriter bufferEscrita) throws IOException {
		bufferEscrita.write("FOLHA DE PAGAMENTO DO DIA " + dataFolha);
		bufferEscrita.newLine();
		bufferEscrita.write("====================================");
		bufferEscrita.newLine();
		bufferEscrita.newLine();
	}
	
	
}
