package Exceptions;

public class AtributoNulo extends Exception{
	private static final long serialVersionUID = 1L;

	public AtributoNulo(String atrib) {
		super(atrib + " nao pode ser nulo.");
	}
}
