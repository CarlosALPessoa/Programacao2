package br.ufal.ic.p2.wepayu;

public class escreverArquivo extends Facade{

	static String escreverHorista(String nome, String hrsTotais, String extras, String salary,
			String descontosS, String salaryL, String metodo) {
		return nome + "                            " 
			+ hrsTotais + "     " 
			+ extras + "        " 
			+ salary + "     " 
			+ descontosS + "           "
			+salaryL+ " " 
			+ metodo;
	}

	static String rodapeHorista(String totalHrS, String totalExtraS, String salarioBS, String descontosS,
			String totalSLiqS) {
		// TODO Auto-generated method stub
		return "TOTAL HORISTAS                          " 
				+ totalHrS + "     "
				+ totalExtraS + "        "
				+ salarioBS + "     " 
				+ descontosS + "          " 
				+ totalSLiqS;
	}
}

