package br.ufal.ic.p2.wepayu;

public class Facade implements ServicosEmpregado {	
	public void encerrarSistema() {
		return;
	}
	
	/*
	 * 
	 * 
	 * 
	 * FUNÇÕES DE ALTERACAO
	 * 
	 * 
	 * 
	 * */
	
	//Excluir todos os registros salvos
	public void zerarSistema() {
		auxFacade.limparRegistro();
	}

	//Criação Empregado Padrão
	public String criarEmpregado(String nome, String endereco, String tipo, String salario) throws Exception {
		return auxFacade.createEmpP(nome, endereco, tipo, salario);
	}
		
	// Cria Empregado com comissao
	public String criarEmpregado(String nome, String endereco, String tipo, String salario, String nP)
			throws Exception {
		return auxFacade.createEmpC(nome, endereco, tipo, salario, nP);
	}
	
	// Excluir empregado do registro
	public String removerEmpregado(String emp) throws Exception {
		auxFacade.removeEmp(emp);
		return emp;
	}

	// CARTÃO DE PONTO
	public void lancaCartao(String emp, String data, String horas) throws Exception {
		auxFacade.cartaoPonto(emp, data, horas);
	}
	
	//VENDAS COMISSIONADAS
	public void lancaVenda(String emp, String dati, String valor) throws Exception {
		auxFacade.vendaComissao(emp, dati, valor);
	}
	
	// Altera atributos simples #3atributos
	public void alteraEmpregado(String emp, String atributo, String valor) throws Exception {
		auxFacade.alteraAtributosEmp(emp, atributo, valor);
	}
	
	//Alteração empregado para sindicalizado #5atributos
	public void alteraEmpregado(String emp, String atributo, String valor, String valor1, String valor2)
				throws Exception {
		//empregado, atributo sindicalizado, valor true or falso, idSindicalizado  taxaSinical
		auxFacade.alteraPSindicalizado(emp, atributo, valor, valor1, valor2);
	}
	
	// Lançamento de taxas do dia especificado para o empregado
	public void lancaTaxaServico(String membro, String data, String valor) throws Exception {
		auxFacade.taxaParaServico(membro, data, valor);
	}
	
	// Alterar forma de pagamento #6atributos
	public void alteraEmpregado(String emp, String atributo, String formaPaga, String banco, String agencia, String contaCorrente) throws Exception {
		auxFacade.alteraMetdsPaga(emp, atributo, formaPaga, banco, agencia, contaCorrente);
	}
	
	//Altera empregado para comissionado ou horista
	public void alteraEmpregado(String emp, String atributo, String tipoEmp, String valor) throws Exception {
		auxFacade.alteraTipoEmp(emp, atributo, tipoEmp, valor);
	}
		
	
	/*
	 * 
	 * 
	 * 
	 * FUNÇÕES GETTERS
	 * 
	 * 
	 * 
	 * */

	// Empregado por nome
	public String getEmpregadoPorNome(String nome, String indice) throws Exception {
		return auxFacade.pesquisaPorNome(nome, indice);
	}

	// Consultar por Atributo
	public String getAtributoEmpregado(String emp, String atributo) throws Exception {
		return auxFacade.pesquisaPorAtributo(emp, atributo);
	}

	//Busca as horas extras do funcionario
	public String getHorasExtrasTrabalhadas(String emp, String inicial, String fim) throws Exception {
		return auxFacade.verHorasExtrasT(emp, inicial, fim);
	}

	public String getHorasNormaisTrabalhadas(String emp, String dataInicio, String dataFinal) throws Exception {
		return auxFacade.verHorasNormaisT(emp, dataInicio, dataFinal);
	}
	
	// RESGATA PERIODO DE VENDAS DO COMISSIONADO
	public String getVendasRealizadas(String emp, String dataI, String dataF) throws Exception {
		return auxFacade.vendasPeriodo(emp, dataI, dataF);			
	}
	
	public String getTaxasServico(String emp, String dataI, String dataF) throws Exception {
		return auxFacade.totalTaxasPeriodo(emp, dataI, dataF);
	}
	
	
	/***
	 * 
	 * AINDA NAO ATUALIZADAS
	 * 
	***/
	
	// Escreve a folha de pagamento
	public void rodaFolha(String data, String saida) throws Exception {
		//String tfolha = totalFolha(data);
		//escreverArquivo.escrita(data, saida, tfolha);
		auxFacade.relatorioFolha(data, saida);
		return;
	}
	
	// Pega o total da folha
	public String totalFolha(String data) throws Exception {
		return auxFacade.totalDespesas(data);
		
		/*Float totalFolha = 0.00f;
	
		for (Empregado emp : emps.values()) {
			if (emp.getTipo().equals("horista")) {
				if (emp instanceof Horista) {
					Horista hr = (Horista) emp;
					totalFolha += hr.PFolhaSemanal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado hr = (Sindicalizado) emp;
					totalFolha += hr.PagamentoFolha(data);
				}
			} else if (emp.getTipo().equals("comissionado")) {
				if (emp instanceof Comissionado) {
					Comissionado comis = (Comissionado) emp;
					totalFolha += comis.pFolhaQuinzenal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado sindC = (Sindicalizado) emp;
					totalFolha += sindC.pFolhaQuinzenal(data);
				}
			} else if (emp.getTipo().equals("assalariado")) {
				if (emp instanceof Empregado) {
					totalFolha += emp.pFolhaMes(data);
				}
			}
		}
		DecimalFormat formato = new DecimalFormat("#,##0.00");
		String totalFolhas = formato.format(totalFolha);
		String totalFolhas2 = totalFolhas.replaceAll("\\.", "");*/
}


}
