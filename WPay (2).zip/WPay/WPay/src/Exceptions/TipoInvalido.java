package Exceptions;

public class TipoInvalido extends Exception{
	private static final long serialVersionUID = 1L;

	public TipoInvalido(String tipo) {
		super(tipo + " invalido.");
	}
}
