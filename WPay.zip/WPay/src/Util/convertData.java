package Util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class convertData {
	
	
	
	public static LocalDate converterFim(String fim) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate dtf = LocalDate.parse(fim, formatter);
			if (Validadores.validarData(fim)) {
				return dtf;
			} else {
				throw new Exception("Data final invalida.");
			}
		} catch (Exception e) {
			throw new Exception("Data final invalida.");
		}
	}
	
	public static LocalDate converterInicio(String inicio) throws Exception {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

		try {
			// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new Exception("Data inicial invalida.");
		}
	}	
}
