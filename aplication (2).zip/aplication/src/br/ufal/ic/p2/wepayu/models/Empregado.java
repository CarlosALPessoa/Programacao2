package br.ufal.ic.p2.wepayu.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Empregado {
	private String nome;
	private String endereco;
	private String tipo;
	private String salary;
	private String sindicalizado = "false";
	private String comissao;
	private String metododePagamento = "emMaos";
	private String banco = "";
	private String agencia = "";
	private String cc = "";

	private LocalDate diaPaga;

//Construtores
	public void setMetododePagamento(String metododePagamento) {
		this.metododePagamento = metododePagamento;
		return;
	}

	public Empregado(String nome, String endereco, String tipo, String salario) throws Exception {
		this.nome = nome;
		this.endereco = endereco;
		this.tipo = tipo;
		this.salary = setSalario(salario);

		setDiaPaga("1/1/2005");
	}

	public Empregado(String nome, String endereco, String tipo, String salario, String comissao) throws Exception {
		this.nome = nome;
		this.endereco = endereco;
		this.tipo = tipo;
		this.salary = setSalario(salario);
		this.comissao = setComissao(comissao);

		setDiaPaga("1/1/2005");
	}
	//FuncaoFolha
	public Float pFolhaMes(String data) throws Exception {
		LocalDate dataFim = converterInicio(data);
		LocalDate diaPag = getDiaPaga();
		//Integer menosdia = 0;

		//Float salarioNormal = Float.parseFloat(getSalario().replace(",", "."));
		while (diaPag.isBefore(dataFim) || diaPag.equals(dataFim)) {
			if (diaPag.equals(dataFim)) {
				return Float.parseFloat(getSalario().replace(",", "."));
			}

			diaPag = diaPag.plusMonths(1);
		}
		
		return 0.0f;
	}
	

//Getters e setters
	public LocalDate getDiaPaga() {
		return diaPaga;
	}
	
	private LocalDate converterInicio(String inicio) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			return LocalDate.parse(inicio, formatter);
		} catch (Exception e) {
			throw new Exception("Data inicial invalida.");
		}
	}

	public Boolean validarData(String dtf) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		sdf.setLenient(false); // Impede interpretações flexíveis, ou seja, datas inválidas serão rejeitadas

		try {
			sdf.parse(dtf);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public void setDiaPaga(String string) throws Exception {
		LocalDate x = converterInicio(string);
		x = x.plusMonths(1);
		x = x.minusDays(1);
		this.diaPaga = x;
		
		return;
	}
	
	public String setSalario(String salario) {
		float num = Float.parseFloat(salario.replace(",", "."));
		this.salary = String.format("%.2f", num);
		return this.salary;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empregado other = (Empregado) obj;
		return Objects.equals(nome, other.nome);
	}

	public String getComissao() {
		return comissao;
	}

	public String setComissao(String comissao) {
		float num = Float.parseFloat(comissao.replace(",", "."));
		return this.comissao = String.format("%.2f", num);
	}

	public String getSindicalizado() {
		return sindicalizado;
	}

	public void setSindicalizado(String sindicalizado) {
		this.sindicalizado = sindicalizado;
		return;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
		return;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
		return;
	}

	public String getSalario() {
		return this.salary;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
		return;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
		return;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
		return;
	}

	public String getMetododePagamento() {
		return metododePagamento;
	}

}
