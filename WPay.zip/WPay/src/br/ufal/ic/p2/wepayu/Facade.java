package br.ufal.ic.p2.wepayu;

import java.util.LinkedHashMap;
import java.util.Map;

import br.ufal.ic.p2.wepayu.models.Comissionado;
import br.ufal.ic.p2.wepayu.models.Empregado;
import br.ufal.ic.p2.wepayu.models.Horista;
import br.ufal.ic.p2.wepayu.models.Sindicalizado;

public class Facade implements ServicosEmpregado {
	//public static String arq = "src/arquivosTxt/emps_data.txt";
	static Map<String, Empregado> emps = new LinkedHashMap<>();
	
	public void encerrarSistema() {
		return;
	}
	
	/*
	 * 
	 * 
	 * 
	 * FUNÇÕES DE ALTERACAO
	 * 
	 * 
	 * 
	 * */
	
	//Excluir todos os registros salvos
	public void zerarSistema() {
		auxFacade.limparRegistro();
	}

	//Criação Empregado Padrão
	public String criarEmpregado(String nome, String endereco, String tipo, String salario) throws Exception {
		return auxFacade.createEmpP(nome, endereco, tipo, salario);
	}
		
	// Cria Empregado com comissao
	public String criarEmpregado(String nome, String endereco, String tipo, String salario, String nP)
			throws Exception {
		return auxFacade.createEmpC(nome, endereco, tipo, salario, nP);
	}
	
	// Excluir empregado do registro
	public String removerEmpregado(String emp) throws Exception {
		auxFacade.removeEmp(emp);
		return emp;
	}

	// CARTÃO DE PONTO
	public void lancaCartao(String emp, String data, String horas) throws Exception {
		auxFacade.cartaoPonto(emp, data, horas);
	}
	
	//VENDAS COMISSIONADAS
	public void lancaVenda(String emp, String dati, String valor) throws Exception {
		//validar(emp);
		auxFacade.vendaComissao(emp, dati, valor);
		
		Float paga = Float.parseFloat(valor.replace(",", "."));
		if (paga < 0 || paga == 0) {
			throw new Exception("Valor deve ser positivo.");
		}

		if (emps.get(emp).getTipo().equals("comissionado")) {
			if (emps.get(emp).getSindicalizado().equals("false")) {
				Comissionado id = (Comissionado) emps.get(emp);
				id.registrarValor(dati, paga);
				return;
			} else if (emps.get(emp).getSindicalizado().equals("true")) {
				Sindicalizado id = (Sindicalizado) emps.get(emp);
				id.registrarValor(dati, paga);
				return;
			}

		}
		throw new Exception("Empregado nao eh comissionado.");
	}
	
	
	/*
	 * 
	 * 
	 * 
	 * FUNÇÕES GETTERS
	 * 
	 * 
	 * 
	 * */

	// Empregado por nome
	public String getEmpregadoPorNome(String nome, String indice) throws Exception {
		return auxFacade.pesquisaPorNome(nome, indice);
	}

	// Consultar por Atributo
	public String getAtributoEmpregado(String emp, String atributo) throws Exception {
		return auxFacade.pesquisaPorAtributo(emp, atributo);
	}

	//Busca as horas extras do funcionario
	public String getHorasExtrasTrabalhadas(String emp, String inicial, String fim) throws Exception {
		return auxFacade.verHorasExtrasT(emp, inicial, fim);
	}

	public String getHorasNormaisTrabalhadas(String emp, String dataInicio, String dataFinal) throws Exception {
		return auxFacade.verHorasNormaisT(emp, dataInicio, dataFinal);
	}
	
	//AINDA NAO ATUALIZADAS
	

	// Para sindicalizados
	public void lancaTaxaServico(String membro, String data, String valor) throws Exception {
		if (membro.isEmpty() || membro == null) {
			throw new Exception("Identificacao do membro nao pode ser nula.");
		}

		for (Empregado emp : emps.values()) {
			if (emp instanceof Sindicalizado) {
				Sindicalizado id = (Sindicalizado) emp;
				if (id.getIdSind().equals(membro)) {
					Float taxa = Float.parseFloat(valor.replace(",", "."));
					if (taxa < 0 || taxa == 0) {
						throw new Exception("Valor deve ser positivo.");
					}
					id.registrarTaxaServico(data, taxa);
					return;
				}
			}
		}
		throw new Exception("Membro nao existe.");
	}

	public String getTaxasServico(String emp, String dataI, String dataF) throws Exception {
		//validar(emp);
		if (emps.get(emp) instanceof Sindicalizado) {
			Sindicalizado id = (Sindicalizado) emps.get(emp);
			return id.obterTaxaComissao(dataI, dataF);
		}
		throw new Exception("Empregado nao eh sindicalizado.");
	}

	// Alterar forma de pagamento #6
	public void alteraEmpregado(String emp, String atributo, String valor1, String banco, String agencia,
			String contaCorrente) throws Exception {
		//validar(emp);

		/*validarParametro(banco, "Banco");
		validarParametro(agencia, "Agencia");
		validarParametro(contaCorrente, "Conta corrente");
		*/
		switch (atributo) {
		case "metodoPagamento":
			emps.get(emp).setMetododePagamento(valor1);
			emps.get(emp).setBanco(banco);
			emps.get(emp).setAgencia(agencia);
			emps.get(emp).setCc(contaCorrente);
			return;
		default:
			throw new IllegalArgumentException("Atributo invalido.");
		}
	}

	// Alteracao para sindicalizado com detalhamento #5
	/*public void alteraEmpregado(String emp, String atributo, String valor, String valor1, String valor2)
			throws Exception {
		// Empregado, atributo, se é sindicalizado, id do sindicato, taxa do sindicato
		validar(emp);

		if (valor1.isEmpty() || valor1 == null) {
			throw new Exception("Identificacao do sindicato nao pode ser nula.");
		}
		validarValorNum(valor2, "Taxa sindical");

		switch (atributo) {
		case "sindicalizado": {
			if (valor.equals("true")) {
				Empregado id = emps.get(emp);

				for (Empregado s : emps.values()) {
					// percorre procurando pelos sindicalizados
					if (s instanceof Sindicalizado) {

						Sindicalizado outroSind = (Sindicalizado) s;
						// Se o membro for igual nao atribui a lista de empregados
						if (outroSind.getIdSind().equals(valor1)) {
							throw new Exception("Ha outro empregado com esta identificacao de sindicato");
						}
					}
				}

				Sindicalizado sind = new Sindicalizado(id.getNome(), id.getEndereco(), id.getTipo(), id.getSalario(),
						valor, id.getMetododePagamento(), id.getBanco(), id.getAgencia(), id.getCc(), valor1, valor2);
				if (id.getTipo().equals("comissionado")) {
					sind.setComissao(id.getComissao());
				}
				emps.put(emp, sind);
				return;
			}
		}
		default:
			throw new IllegalArgumentException("Atributo invalido.");
		}
	}*/

	// Altera atributos #4 Comissionado e Horista
	public void alteraEmpregado(String emp, String atributo, String valor, String valor1) throws Exception {
		//validar(emp);
		switch (atributo) {
		case "tipo":
			Empregado id = emps.get(emp);

			if (valor.equals("horista")) {
				Horista hr = new Horista(id.getNome(), id.getEndereco(), valor, valor1);
				emps.put(emp, hr);
				return;
			}
			Comissionado comis = new Comissionado(id.getNome(), id.getEndereco(), valor, id.getSalario(), valor1);
			emps.put(emp, comis);

			return;
		default:
			throw new Exception("Atributo nao existe.");
		}
	}
	
	// Comissionado funcoes
	public String getVendasRealizadas(String emp, String dataI, String dataF) throws Exception {
		//validar(emp);
		if (emps.get(emp).getTipo().equals("comissionado")) {
			Comissionado id = (Comissionado) emps.get(emp);
			return id.obterValor(dataI, dataF);
		}
		throw new Exception("Empregado nao eh comissionado.");
	}


	
	// Altera atributos simples #3
		/*public void alteraEmpregado(String emp, String atributo, String valor) throws Exception {
			validar(emp);

			switch (atributo) {
			// Padrao Empregado
			case "nome":
				validarParametro(valor, "Nome");
				emps.get(emp).setNome(valor);
				return;

			case "endereco":
				validarParametro(valor, "Endereco");
				emps.get(emp).setEndereco(valor);
				return;
			case "tipo":
				validarParametro(valor, "Tipo");
				emps.get(emp).setTipo(valor);
				return;
			case "salario":
				validarSalarioNum(valor);
				emps.get(emp).setSalario(valor);
				return;
			// Fim Padrão Empregado

			case "sindicalizado": {
				if (valor.equals("false") || valor.equals("true")) {
					emps.get(emp).setSindicalizado(valor);
					return;
				} else {
					throw new Exception("Valor deve ser true ou false.");
				}
			}
			case "comissao":
				if (emps.get(emp) instanceof Comissionado) {
					validarValorNum(valor, "Comissao");
					emps.get(emp).setComissao(valor);
					return;
				} else {
					throw new Exception("Empregado nao eh comissionado.");
				}
			case "metodoPagamento":
				if (valor.equals("emMaos") || valor.equals("banco") || valor.equals("correios")) {
					emps.get(emp).setMetododePagamento(valor);
					return;
				}
				throw new Exception("Metodo de pagamento invalido.");
			default:
				throw new IllegalArgumentException("Atributo nao existe.");
			}
		}*/

	
	// Escreve a folha de pagamento
	public void rodaFolha(String data, String saida) throws Exception {
		//String tfolha = totalFolha(data);
		//escreverArquivo.escrita(data, saida, tfolha);
		return;
	}
	
	// Pega o total da folha
	public void totalFolha(String data) throws Exception {
		
		/*Float totalFolha = 0.00f;
	
		for (Empregado emp : emps.values()) {
			if (emp.getTipo().equals("horista")) {
				if (emp instanceof Horista) {
					Horista hr = (Horista) emp;
					totalFolha += hr.PFolhaSemanal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado hr = (Sindicalizado) emp;
					totalFolha += hr.PagamentoFolha(data);
				}
			} else if (emp.getTipo().equals("comissionado")) {
				if (emp instanceof Comissionado) {
					Comissionado comis = (Comissionado) emp;
					totalFolha += comis.pFolhaQuinzenal(data);
				}
				if (emp instanceof Sindicalizado) {
					Sindicalizado sindC = (Sindicalizado) emp;
					totalFolha += sindC.pFolhaQuinzenal(data);
				}
			} else if (emp.getTipo().equals("assalariado")) {
				if (emp instanceof Empregado) {
					totalFolha += emp.pFolhaMes(data);
				}
			}
		}
		DecimalFormat formato = new DecimalFormat("#,##0.00");
		String totalFolhas = formato.format(totalFolha);
		String totalFolhas2 = totalFolhas.replaceAll("\\.", "");*/
		return;
}


}
