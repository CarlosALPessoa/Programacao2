package Exceptions;

public class EmpregadoNaoExiste extends Exception {
	private static final long serialVersionUID = 1L;

	public EmpregadoNaoExiste() {super("Empregado nao existe.");}
}
