package Exceptions;

public class existeIdSindicato extends Exception{
	private static final long serialVersionUID = 1L;

	public existeIdSindicato() {
		super("Ha outro empregado com esta identificacao de sindicato");
	}
}
