package br.ufal.ic.p2.wepayu;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import Exceptions.EmpregadoNaoAplicavel;
import Exceptions.EmpregadoNaoEncontrado;
import Exceptions.EmpregadoNaoExiste;
import Exceptions.IdNula;
import Exceptions.NaoEhTipo;
import Exceptions.TipoInvalido;
import Util.Validadores;
import Util.convertData;
import br.ufal.ic.p2.wepayu.models.Comissionado;
import br.ufal.ic.p2.wepayu.models.Empregado;
import br.ufal.ic.p2.wepayu.models.Horista;
import br.ufal.ic.p2.wepayu.models.Sindicalizado;

public class auxFacade {
	public static Map<String, Empregado> empss = new LinkedHashMap<>();
	
	//Gerador de identificação unica
	private static String gerarID() {
		return UUID.randomUUID().toString();
	}	

	public static void limparRegistro() {
		empss.clear();
	}
	
	public static Integer totalUser(Map<String, Empregado> emps) {
		return emps.size();
	}

	//Empregado Comissionado
	public static String createEmpC(String nome, String endereco, String tipo, String salario, String comissao) throws Exception {
		if(!tipo.equals("comissionado")) {
			throw new EmpregadoNaoAplicavel();
		}
		
		Validadores.validarComissao(comissao);
		Validadores.validarParametro(nome, "Nome");
		Validadores.validarParametro(endereco, "Endereco");
		Validadores.validarSalario(salario);
		
		Comissionado emp = new Comissionado(nome, endereco, tipo, salario, comissao);
		String id = gerarID();		
		empss.put(id, emp);
		return id;
	}
	
	//Empregado Padrão
	public static String createEmpP(String nome, String endereco, String tipo, String salario) throws Exception {
		if(tipo.equals("comissionado")) {
			throw new EmpregadoNaoAplicavel();
		}		
		if(!tipo.equals("horista") && !tipo.equals("assalariado")) {
			throw new TipoInvalido();
		}
		
		String id = gerarID();

		Validadores.validarParametro(nome, "Nome");
		Validadores.validarParametro(endereco, "Endereco");
		Validadores.validarSalario(salario);
		
		
		if(tipo.equals("horista")) {
			Horista emp = new Horista(nome, endereco, tipo, salario);
			empss.put(id, emp);
		}else {
			Empregado emp = new Empregado(nome, endereco, tipo, salario);
			empss.put(id, emp);
		}		
		return id;
	}
	
	//Busca o atributo do empregado
	public static String pesquisaPorAtributo(String emp, String atributo) throws Exception {
		Validadores.validar(emp);
		
		if(!empss.isEmpty()) {	
			switch (atributo) {
				case "nome" : 
					return empss.get(emp).getNome();
				case "endereco":
					return empss.get(emp).getEndereco();
				case "tipo":
					return empss.get(emp).getTipo();
				case "salario":
					return empss.get(emp).getSalario();
				case "sindicalizado":
					return empss.get(emp).getSindicalizado();
				
				case "comissao":
					if(empss.get(emp) instanceof Comissionado) {
						Comissionado coms = (Comissionado) empss.get(emp);
						return coms.getComissao();
					}
					else {
						throw new Exception("Empregado nao eh comissionado.");
					}
				}
		}
		else {
			
		}
		throw new Exception("Atributo nao existe.");
	}

	//busca por nome
	public static String pesquisaPorNome(String nome, String indice) throws EmpregadoNaoEncontrado {
		Integer id = Integer.parseInt(indice);

		for (Map.Entry<String, Empregado> emp : empss.entrySet()) {
			if (emp.getValue().getNome().contains(nome)) {
				id -= 1;
				if (id == 0) {
					return emp.getKey();
				}
			}
		}
		throw new EmpregadoNaoEncontrado();
	}

	//remove do registro o empregado
	public static void removeEmp(String emp) throws Exception {
		Validadores.validar(emp);
		if (!empss.isEmpty()) {
			for (Map.Entry<String, Empregado> empr : empss.entrySet()) {
				if (empr.getKey().equals(emp)) {
					empss.keySet().remove(emp);
					return;
				}
			}

		} else {
			throw new IdNula();
		}
		throw new EmpregadoNaoExiste();
	}

	//Lanca as horas do dia especificado
	public static void cartaoPonto(String emp, String data, String horas) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
	
		Validadores.validarHour(horas, "Horas");
		if(Validadores.validarData(data).equals(false)) {
			throw new Exception("Data invalida.");
		}
		
		empss.get(emp).setHorasTrabalhadas(data, horas);
	}
	
	//Retorna o total de horas normais trabalhadas
	public static String verHorasNormaisT(String emp, String dataInicio, String dataFinal) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
		
		Float normalHr = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		
		LocalDate datai = convertData.converterInicio(dataInicio);
		LocalDate dataf = convertData.converterFim(dataFinal);

		if (!datai.isBefore(dataf) && !datai.equals(dataf)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}
		
		while(datai.isBefore(dataf)) {			
			String dataPegaHr = formatter.format(datai);
			Float horas = 0.0f;
			
			if(empss.get(emp).getHorasTrabalhadas().containsKey(dataPegaHr)) {
				horas = Float.parseFloat(empss.get(emp)
						.getHorasTrabalhadas().get(dataPegaHr)
						.replace(",", "."));
			}
			
			if (horas > 8.0f) {
				normalHr += 8;
			} else if (horas <= 8.0f && horas > 0.0f) {
				normalHr += horas;
			}
			
			datai = datai.plusDays(1);
		}
		return String.format("%d", Float.valueOf(normalHr).intValue());
	}

	//Retorna o total de horas extras trabalhadas
	public static String verHorasExtrasT(String emp, String inicial, String fim) throws Exception {
		Validadores.validar(emp);
		if(!empss.get(emp).getTipo().equals("horista")) {
			throw new NaoEhTipo("horista");
		}
		Float horasExtras = 0.0f;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		// float horasDiarias = 8;

		LocalDate datai = convertData.converterInicio(inicial);
		LocalDate dataf = convertData.converterFim(fim);
		
		if (!datai.isBefore(dataf) && !datai.equals(dataf)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}
		
		if(empss.get(emp).getHorasTrabalhadas().isEmpty()) {
			return "0";
		}
		
		while (!datai.equals(dataf)) {
			String dates = formatter.format(datai);
			
			Float hrExtra = 0.0f;
			if(empss.get(emp).getHorasTrabalhadas().containsKey(dates)) {
				hrExtra = Float.parseFloat(empss.get(emp)
						.getHorasTrabalhadas()
						.get(dates)
						.replace(",", "."));
			}
			
			if (hrExtra != null) {
				if (hrExtra > 8 && hrExtra >= 0) {
					horasExtras += hrExtra - 8;				
				}
			}
			datai = datai.plusDays(1);
		}
		if(horasExtras % 1 != 0) {
	        return String.format("%.1f", horasExtras);
		}
		else {
			return String.format("%d", Float.valueOf(horasExtras).intValue());
		}
	}

	public static void vendaComissao(String emp, String dati, String valor) throws Exception {
		if(!empss.get(emp).getTipo().equals("comissionado")){
			throw new NaoEhTipo("comissionado");
		}
		
		Float paga = Float.parseFloat(valor.replace(",", "."));
		if (paga < 0 || paga == 0) {
			throw new Exception("Valor deve ser positivo.");
		}

		if (empss.get(emp) instanceof Comissionado) { 
		
				empss.get(emp).registrarValor(dati, paga);
				return;
		} 
		/*else if (empss.get(emp).getSindicalizado().equals("true")) {
				Sindicalizado id = (Sindicalizado) empss.get(emp);
				id.registrarValor(dati, paga);
				return;
			}

		}*/
		throw new Exception("Empregado nao eh comissionado.");
	}
	
	
}
