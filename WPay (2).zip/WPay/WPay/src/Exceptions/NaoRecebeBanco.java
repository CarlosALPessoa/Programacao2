package Exceptions;

public class NaoRecebeBanco extends Exception{
	private static final long serialVersionUID = 1L;

	public NaoRecebeBanco() {
		super("Empregado nao recebe em banco.");
	}
}
