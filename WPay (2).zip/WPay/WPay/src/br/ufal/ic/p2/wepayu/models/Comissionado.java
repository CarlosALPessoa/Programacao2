package br.ufal.ic.p2.wepayu.models;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

import Util.convertData;

public class Comissionado extends Empregado {
	private Map<String, Float> vComissaoVenda;
	private String realSalario;
	private String comissao;

//Construtor
	public Comissionado(String nome, String endereco, String tipo, String salario, String comissao) throws Exception {
		super(nome, endereco, tipo, salario);
		this.comissao = comissao;
		setTipo("comissionado");
		this.comissao = comissao;
		this.vComissaoVenda = new LinkedHashMap<>();
		setrealSalario(salario);
		setDiaPaga("1/1/2005");
	}
	
	/*
	 * 
	 * Funções
	 * 
	 * */
	
	public void setrealSalario(String realSalario) {
		Float salary = Float.parseFloat(realSalario.replace(",", "."));
		
		Integer salarioComissaoi = (int) (salary * 100);
		salary= salarioComissaoi / 100.0f;
		salary = (salary * 12.0f)/ 52.0f;
		salary *= 2.0f;
        DecimalFormat decimalFormatter = new DecimalFormat("#,##0.00");
        this.realSalario = decimalFormatter.format(salary);
        return;
	}
	
	public void registrarValor(String data, Float valor) throws Exception {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
			LocalDate.parse(data, formatter);
			vComissaoVenda.put(data, valor);
			return;
		} catch (Exception e) {
			throw new Exception("Data invalida.");
		}
	}
	
	public String obterValor(String inicio, String fim) throws Exception {
		Float comissao = 0.00f;
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		LocalDate datai = convertData.converterInicio(inicio);
		LocalDate dataf = convertData.converterFim(fim);

		if (dataf.isBefore(datai)) {
			throw new Exception("Data inicial nao pode ser posterior a data final.");
		}

		for (LocalDate data = datai; data.isBefore(dataf); data = data.plusDays(1)) {
			String dates = data.format(formatter);
			Float objeto = vComissaoVenda.get(dates);

			if (objeto != null) {
				comissao += objeto;
			}
		}
		if (comissao != 0) {
			return String.format("%.2f", comissao);
		}
		return "0,00";
	}
	
	/*
	 * 
	 * GETTERS E SETTERS
	 * 
	 * */
	
	@Override
	public void setDiaPaga(String diaPaga) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
		LocalDate temp = LocalDate.parse(diaPaga, formatter).plusDays(14);		
		this.diaPaga = temp.format(formatter);
	}

	public String getComissao() {
		return comissao;
	}

	public void setComissao(String comissao) {
		this.comissao = comissao;
	}
	
	public String getRealSalario() {
		return realSalario;
	}
	
	/*
	public Float pFolhaQuinzenal(String data) throws Exception {
		LocalDate dataFim = converterFim(data);
		LocalDate diaPag = getDiaDePagamento();
		Integer menosdia = 0;
		if (diaPag.getDayOfWeek() == DayOfWeek.SATURDAY) {
			diaPag = diaPag.minusDays(1);
			menosdia = 1;
		} else if (diaPag.getDayOfWeek() == DayOfWeek.SUNDAY) {
			diaPag = diaPag.minusDays(2);
			menosdia = 2;
		}

		Float salarioNormal = (float) Float.parseFloat(getRealSalario().replace(",", "."));
		Float salarioComissao = 0.00f;

		while (diaPag.isBefore(dataFim) || diaPag.equals(dataFim)) {
			if (diaPag.equals(dataFim)) {
				dataFim = dataFim.plusDays(1);
				diaPag = getDiaDePagamento().minusDays(14);
				if (!vComissaoVenda.isEmpty()) {
					
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
					String dataInicial = formatter.format(diaPag);
					String datafims = formatter.format(dataFim);
					Float totalValorVendas = Float.parseFloat(obterValor(dataInicial, datafims).replace(",", "."));
					
					float ganhoRate = totalValorVendas * Float.parseFloat(getComissao().replace(",", "."));
					salarioComissao = salarioNormal + ganhoRate;
					
					Integer salarioComissaoi = (int) (salarioComissao * 100);
					salarioComissao = salarioComissaoi / 100.0f;
					
					setDiaDePagamento(data);
					return salarioComissao;
				}
				Integer salarioComissaoi = (int) (salarioNormal * 100);
				salarioNormal = salarioComissaoi / 100.0f;
				setDiaDePagamento(data);
				return salarioNormal;
			}
			diaPag = diaPag.plusDays(15 - menosdia);
		}
		return 0.00f;
	}
	*/	
}