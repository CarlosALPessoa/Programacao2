package br.ufal.ic.p2.wepayu.models;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class Empregado {
	private String nome;
	private String endereco;
	private String tipo;
	private String salary;
	private String sindicalizado = "false";
	private String metododePagamento = "emMaos";
	private String banco = "";
	private String agencia = "";
	private String cc = "";

	private Map<String, String> horasTrabalhadas = new LinkedHashMap<>();
	
	//private LocalDate diaPaga;

//Construtores
	public void setMetododePagamento(String metododePagamento) {
		this.metododePagamento = metododePagamento;
		return;
	}

	public Empregado(String nome, String endereco, String tipo, String salario){
		this.nome = nome;
		this.endereco = endereco;
		this.tipo = tipo;
		this.salary = setSalario(salario);

		//this.diaPaga = LocalDate.parse("1/1/2015");
	}
	
	//FuncaoFolha
	
	public String setSalario(String salario) {
		float num = Float.parseFloat(salario.replace(",", "."));
		this.salary = String.format("%.2f", num);
		return this.salary;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empregado other = (Empregado) obj;
		return Objects.equals(nome, other.nome);
	}

	public String getSindicalizado() {
		return sindicalizado;
	}

	public void setSindicalizado(String sindicalizado) {
		this.sindicalizado = sindicalizado;
		return;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
		return;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
		return;
	}

	public String getSalario() {
		return this.salary;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
		return;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
		return;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
		return;
	}

	public String getMetododePagamento() {
		return metododePagamento;
	}

	public Map<String, String> getHorasTrabalhadas() {
		return horasTrabalhadas;
	}

	public void setHorasTrabalhadas(String data, String horas) {
		this.horasTrabalhadas.put(data, horas);
	}

}
