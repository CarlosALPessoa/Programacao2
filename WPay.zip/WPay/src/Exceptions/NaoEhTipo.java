package Exceptions;

public class NaoEhTipo extends Exception{
	private static final long serialVersionUID = 1L;

	public NaoEhTipo(String tipo) {
		super("Empregado nao eh " + tipo +".");
	}
}
