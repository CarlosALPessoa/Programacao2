package Exceptions;

public class EmpregadoNaoEncontrado extends Exception{
	private static final long serialVersionUID = 1L;

	public EmpregadoNaoEncontrado() {
		super("Nao ha empregado com esse nome.");
	}
}
