package Exceptions;

public class IdSindEmpNula extends Exception {
	private static final long serialVersionUID = 1L;

	public IdSindEmpNula(String tipo) {
		super("Identificacao do "+ tipo + " nao pode ser nula.");
	}
}
